package moosh.tutorialmod.proxy;

import moosh.tutorialmod.init.entities.EntityCannonMaster;
import moosh.tutorialmod.init.entities.EntityCannonball;
import moosh.tutorialmod.init.entities.RenderCannonMaster;
import moosh.tutorialmod.init.entities.RenderCannonball;
import net.minecraft.client.model.ModelPlayer;
import net.minecraftforge.fml.client.registry.RenderingRegistry;

/**
 * 
 * @author Blam
 * 
 * This class is not for server-side code in your mod.
 *
 */
public class ClientProxy extends CommonProxy{
  
	public void registerEntityRenderers() {
		RenderCannonMaster renderer = new RenderCannonMaster(new ModelPlayer(0, false), 0.75f);
		RenderingRegistry.registerEntityRenderingHandler(EntityCannonMaster.class, renderer);
		//Minecraft.getMinecraft().getRenderManager();
//		RenderClone renderer2 = new RenderClone();
//		
//		RenderingRegistry.registerEntityRenderingHandler(EntityClone.class, renderer2);
//

    	RenderingRegistry.registerEntityRenderingHandler(EntityCannonball.class, new RenderCannonball());
    	
    	
    	

    }
	
}
