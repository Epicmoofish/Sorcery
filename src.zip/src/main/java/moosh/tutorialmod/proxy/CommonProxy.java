package moosh.tutorialmod.proxy;

/**
 * 
 * @author Blam
 * 
 * This class is for server-side code in your mod.
 *
 */
public class CommonProxy {
    public void registerEntityRenderers() {
		// TODO Auto-generated method stub
    	
		// Don't do anything because this will run server side - there's no rendering on server side.
	}
    
}
