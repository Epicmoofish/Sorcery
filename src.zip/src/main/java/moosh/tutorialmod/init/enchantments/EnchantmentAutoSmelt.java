package moosh.tutorialmod.init.enchantments;

import moosh.tutorialmod.TutorialMod;
import moosh.tutorialmod.init.EnchantmentInit;
import net.minecraft.enchantment.Enchantment;
import net.minecraft.enchantment.EnumEnchantmentType;
import net.minecraft.init.Enchantments;
import net.minecraft.inventory.EntityEquipmentSlot;
import net.minecraft.util.ResourceLocation;

public class EnchantmentAutoSmelt extends Enchantment{

	public EnchantmentAutoSmelt() {
		super(Rarity.RARE, EnumEnchantmentType.DIGGER, new EntityEquipmentSlot[] {EntityEquipmentSlot.MAINHAND});
		// TODO Auto-generated constructor stub
		this.setName("auto_smelt");
		this.setRegistryName(new ResourceLocation(TutorialMod.MODID+":auto_smelt"));
		EnchantmentInit.ENCHANTMENTS.add(this);
	}

	/* (non-Javadoc)
	 * @see net.minecraft.enchantment.Enchantment#getMaxLevel()
	 */
	@Override
	public int getMaxLevel() {
		// TODO Auto-generated method stub
		return 1;
	}

	/* (non-Javadoc)
	 * @see net.minecraft.enchantment.Enchantment#getMinEnchantability(int)
	 */
	@Override
	public int getMinEnchantability(int enchantmentLevel) {
		// TODO Auto-generated method stub
		return 20*enchantmentLevel;
	}

	/* (non-Javadoc)
	 * @see net.minecraft.enchantment.Enchantment#canApplyTogether(net.minecraft.enchantment.Enchantment)
	 */
	@Override
	protected boolean canApplyTogether(Enchantment ench) {
		// TODO Auto-generated method stub
		
		return super.canApplyTogether(ench)&& ench != Enchantments.SILK_TOUCH;
	}

	/* (non-Javadoc)
	 * @see net.minecraft.enchantment.Enchantment#onEntityDamaged(net.minecraft.entity.EntityLivingBase, net.minecraft.entity.Entity, int)
	 */

	/* (non-Javadoc)
	 * @see net.minecraft.enchantment.Enchantment#getMaxEnchantability(int)
	 */
	@Override
	public int getMaxEnchantability(int enchantmentLevel) {
		// TODO Auto-generated method stub
		return getMinEnchantability(enchantmentLevel)+10;
	}

}
