package moosh.tutorialmod.init.enchantments;

import moosh.tutorialmod.TutorialMod;
import moosh.tutorialmod.init.EnchantmentInit;
import net.minecraft.enchantment.Enchantment;
import net.minecraft.enchantment.EnumEnchantmentType;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.inventory.EntityEquipmentSlot;
import net.minecraft.potion.Potion;
import net.minecraft.potion.PotionEffect;
import net.minecraft.util.ResourceLocation;

public class EnchantmentPoisoned extends Enchantment{

	public EnchantmentPoisoned() {
		super(Rarity.UNCOMMON, EnumEnchantmentType.WEAPON, new EntityEquipmentSlot[] {EntityEquipmentSlot.MAINHAND});
		// TODO Auto-generated constructor stub
		this.setName("poisoned");
		this.setRegistryName(new ResourceLocation(TutorialMod.MODID+":poisoned"));
		EnchantmentInit.ENCHANTMENTS.add(this);
	}

	/* (non-Javadoc)
	 * @see net.minecraft.enchantment.Enchantment#getMaxLevel()
	 */
	@Override
	public int getMaxLevel() {
		// TODO Auto-generated method stub
		return 4;
	}

	/* (non-Javadoc)
	 * @see net.minecraft.enchantment.Enchantment#getMinEnchantability(int)
	 */
	@Override
	public int getMinEnchantability(int enchantmentLevel) {
		// TODO Auto-generated method stub
		return 20*enchantmentLevel;
	}

	/* (non-Javadoc)
	 * @see net.minecraft.enchantment.Enchantment#canApplyTogether(net.minecraft.enchantment.Enchantment)
	 */
	@Override
	protected boolean canApplyTogether(Enchantment ench) {
		// TODO Auto-generated method stub
		return true;
	}

	/* (non-Javadoc)
	 * @see net.minecraft.enchantment.Enchantment#onEntityDamaged(net.minecraft.entity.EntityLivingBase, net.minecraft.entity.Entity, int)
	 */
	@Override
	public void onEntityDamaged(EntityLivingBase user, Entity target, int level) {
		// TODO Auto-generated method stub
		if (target instanceof EntityLivingBase) {
			EntityLivingBase targetLiving = (EntityLivingBase)target;
			
			targetLiving.addPotionEffect((new PotionEffect(Potion.getPotionById(20), 100, level)));
		}
		super.onEntityDamaged(user, target, level);
	}

	/* (non-Javadoc)
	 * @see net.minecraft.enchantment.Enchantment#getMaxEnchantability(int)
	 */
	@Override
	public int getMaxEnchantability(int enchantmentLevel) {
		// TODO Auto-generated method stub
		return getMinEnchantability(enchantmentLevel)+10;
	}

}
