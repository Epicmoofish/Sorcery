package moosh.tutorialmod.init.blocks;



 
import java.util.Random;

import moosh.tutorialmod.init.ItemInit;
import net.minecraft.block.state.IBlockState;
import net.minecraft.item.Item;
 
public class DarkQuartzBlock extends CustomBlock{
 
    public static final String name = "dark_quartz_block";
 
    public DarkQuartzBlock(String name, float hardness, float resistance, int harvestlevel) {
        super(name, hardness, resistance, harvestlevel);
        // TODO Auto-generated constructor stub
 
     
        this.setHarvestLevel("pickaxe", harvestlevel);
 
    }




	



	
	
	
 
}