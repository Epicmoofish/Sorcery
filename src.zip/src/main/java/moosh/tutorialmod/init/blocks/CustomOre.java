package moosh.tutorialmod.init.blocks;

import moosh.tutorialmod.TutorialMod;
import net.minecraft.block.Block;
import net.minecraft.block.material.Material;
import net.minecraft.creativetab.CreativeTabs;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;

public class CustomOre extends Block{
	


	public CustomOre(String name, float hardness, float resistance) {
		
        super(Material.ROCK);
        // TODO Auto-generated constructor stub
 
        this.setUnlocalizedName(name);
        this.setCreativeTab(CreativeTabs.BUILDING_BLOCKS);
setHardness(hardness);
        this.setRegistryName(name);
        setResistance(resistance);
        this.setHarvestLevel("pickaxe", 3);
 
    }
}
