package moosh.tutorialmod.init.blocks;



 
import java.util.ArrayList;

import moosh.tutorialmod.init.BlockInit;
import net.minecraft.block.state.IBlockState;
import net.minecraft.entity.Entity;
import net.minecraft.init.Items;
import net.minecraft.item.ItemStack;
import net.minecraft.util.NonNullList;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.IBlockAccess;
import net.minecraft.world.World;
 
public class BlockEnderOre extends CustomOre{
 




	
	public static final String name = "ender_ore";
 
    public BlockEnderOre(String name, float hardness, float resistance, int harvestlevel) {
        super(name, hardness, resistance);
        // TODO Auto-generated constructor stub
 
     
        this.setHarvestLevel("pickaxe", harvestlevel);
 
    }
    public void onEntityCollidedWithBlock(World worldIn, BlockPos pos, IBlockState state, Entity entityIn)
    {
        entityIn.setInWeb();
    }
   
//	@Override
//	public void getDrops(NonNullList<ItemStack> drops, IBlockAccess world, BlockPos pos, IBlockState state,
//			int fortune) {
//		// TODO Auto-generated method stub
//		drops.clear();
//		drops.add(new ItemStack(BlockInit.dark_ore));
//		drops.add(new ItemStack(BlockInit.ender_ore));
//		super.getDrops(drops, world, pos, state, fortune);
//	}
    	
    



	
}


	
	
	
 
