package moosh.tutorialmod.init.blocks;

import java.util.Random;

import moosh.tutorialmod.init.BlockInit;
import moosh.tutorialmod.init.ItemInit;
import net.minecraft.block.state.IBlockState;
import net.minecraft.entity.Entity;
import net.minecraft.entity.item.EntityItem;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;

public class BlockRainbowOre extends CustomOre{
 
    public static final String name = "rainbow_ore";
 
    public BlockRainbowOre(String name, float hardness, float resistance, int harvestlevel) {
        super(name, hardness, resistance);
        // TODO Auto-generated constructor stub
 
     
        this.setHarvestLevel("pickaxe", harvestlevel);
 
    }
   // @Override
	//public void onBlockHarvested(World worldIn, BlockPos pos, IBlockState state, EntityPlayer player) {
		// TODO Auto-generated method stub
   // 	ItemStack x = player.getHeldItemMainhand();
   // if (x.getItem() == ItemInit.darkPick || x.getItem() == ItemInit.rainbowHammer){
    //		Entity item = new EntityItem(worldIn, pos.getX(), pos.getY(), pos.getZ(), new ItemStack(BlockInit.rainbow_ore, 1));
	//		if (!worldIn.isRemote){
    //		worldIn.spawnEntity(item);
		//	}
    //}
    	
		//super.onBlockHarvested(worldIn, pos, state, player);
	//}
	




	



	
	
	
 
}