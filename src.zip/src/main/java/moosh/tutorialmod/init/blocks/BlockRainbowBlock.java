package moosh.tutorialmod.init.blocks;

public class BlockRainbowBlock extends BlockRainbow{
 
    public static final String name = "rainbow_block";
 
    public BlockRainbowBlock(String name, float hardness, float resistance, int harvestlevel) {
        super(name, hardness, resistance);
        // TODO Auto-generated constructor stub
 
     
        this.setHarvestLevel("pickaxe", harvestlevel);
 
    }




	



	
	
	
 
}