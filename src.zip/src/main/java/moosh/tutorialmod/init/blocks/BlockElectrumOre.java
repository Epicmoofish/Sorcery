package moosh.tutorialmod.init.blocks;



 
import java.util.Random;

import moosh.tutorialmod.init.ItemInit;
import net.minecraft.block.state.IBlockState;
import net.minecraft.item.Item;
 
public class BlockElectrumOre extends CustomOre{
 
    public static final String name = "electrum_ore";
 
    public BlockElectrumOre(String name, float hardness, float resistance, int harvestlevel) {
        super(name, hardness, resistance);
        // TODO Auto-generated constructor stub
 
     
        this.setHarvestLevel("pickaxe", harvestlevel);
 
    }

	@Override
	public Item getItemDropped(IBlockState state, Random rand, int fortune) {
		// TODO Auto-generated method stub
		return ItemInit.smallElec;
	}

	 @Override
		public int quantityDropped(IBlockState state, int fortune, Random random) {
			// TODO Auto-generated method stub
		 int upper = 3;
			int x = 1;
			 if (fortune > 0){
			int y = (random.nextInt(fortune)+1)*2;
		

			return x*y;
			 } else
				 return x;
		}
	 @Override
		protected boolean canSilkHarvest() {
			// TODO Auto-generated method stub
			return super.canSilkHarvest();
		}


	



	
	
	
 
}