package moosh.tutorialmod.init.blocks;

import moosh.tutorialmod.TutorialMod;
import net.minecraft.block.Block;
import net.minecraft.block.material.Material;
import net.minecraft.creativetab.CreativeTabs;

public class CustomRanOre extends Block{
	
	public CustomRanOre(String name, float hardness, float resistance) {
		
        super(Material.ROCK);
        // TODO Auto-generated constructor stub
 
        this.setUnlocalizedName(name);
        this.setCreativeTab(CreativeTabs.BUILDING_BLOCKS);
setHardness(hardness);
        this.setRegistryName(name);
        setResistance(resistance);
        this.setHarvestLevel("pickaxe", 3);
 
    }
}
