package moosh.tutorialmod.init.blocks;

import java.util.List;
import java.util.Random;

import javax.annotation.Nullable;

import com.google.common.base.Predicate;

import moosh.tutorialmod.init.BlockInit;
import net.minecraft.block.BlockLeaves;
import net.minecraft.block.BlockPlanks.EnumType;
import net.minecraft.block.SoundType;
import net.minecraft.block.properties.IProperty;
import net.minecraft.block.properties.PropertyEnum;
import net.minecraft.block.state.BlockStateContainer;
import net.minecraft.block.state.IBlockState;
import net.minecraft.creativetab.CreativeTabs;
import net.minecraft.enchantment.EnchantmentHelper;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.init.Blocks;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.util.BlockRenderLayer;
import net.minecraft.util.DamageSource;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.NonNullList;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.IBlockAccess;
import net.minecraft.world.World;
import net.minecraftforge.fml.relauncher.Side;
import net.minecraftforge.fml.relauncher.SideOnly;

public class CustomBlockLeaves extends BlockLeaves implements IMetaName
{
	protected boolean leavesFancy;
	public static final PropertyEnum<Planks.EnumType> VARIANT = PropertyEnum.<Planks.EnumType>create("variant", Planks.EnumType.class, new Predicate<Planks.EnumType>()
	{
		public boolean apply(@Nullable Planks.EnumType apply)
		{
			return apply.getMeta() < 2;
		}
	});
	
	public CustomBlockLeaves(String name) 
	{
		
		setUnlocalizedName(name);
		setRegistryName(name);
		setSoundType(SoundType.PLANT);
		setDefaultState(this.blockState.getBaseState().withProperty(VARIANT, Planks.EnumType.RAINBOW).withProperty(CHECK_DECAY, Boolean.valueOf(true)).withProperty(DECAYABLE, Boolean.valueOf(true)));
	}


	
	@Override
	public IBlockState getStateFromMeta(int meta)
	{
		
		return this.getDefaultState().withProperty(VARIANT, Planks.EnumType.byMetadata(meta % 2)).withProperty(DECAYABLE, Boolean.valueOf((meta & 2) != 0)).withProperty(CHECK_DECAY, Boolean.valueOf((meta & 4) > 0));

	}
	
	@Override
	public int getMetaFromState(IBlockState state) 
	{
		int i = ((Planks.EnumType)state.getValue(VARIANT)).getMeta();
		
		if(((Boolean)state.getValue(DECAYABLE)).booleanValue())
		{
			i |= 2;
		}
		
		if(((Boolean)state.getValue(CHECK_DECAY)).booleanValue())
		{
			i |= 4;
		}
		
		return i;
	}
	@SideOnly(Side.CLIENT)
    public boolean shouldSideBeRendered(IBlockState blockState, IBlockAccess blockAccess, BlockPos pos, EnumFacing side)
    {
        return blockAccess.getBlockState(pos.offset(side)).getBlock() == this ? true : super.shouldSideBeRendered(blockState, blockAccess, pos, side);
    }
	@Override
	public void getSubBlocks(CreativeTabs itemIn, NonNullList<ItemStack> items) 
	{
		for(Planks.EnumType Planks$enumtype : Planks.EnumType.values())
		{
			items.add(new ItemStack(this, 1, Planks$enumtype.getMeta()));
		}
	}
	
	@Override
	protected ItemStack getSilkTouchDrop(IBlockState state) 
	{
		return new ItemStack(Item.getItemFromBlock(this), 1, ((Planks.EnumType)state.getValue(VARIANT)).getMeta());
	}
	
	@Override
	public int damageDropped(IBlockState state) 
	{
		return ((Planks.EnumType)state.getValue(VARIANT)).getMeta();
	}
	
	@Override
	public String getSpecialName(ItemStack stack) 
	{
		return Planks.EnumType.values()[stack.getItemDamage()].getName();
	}
	
	@Override
	protected void dropApple(World worldIn, BlockPos pos, IBlockState state, int chance) {return;}
	
	@Override
	protected int getSaplingDropChance(IBlockState state) {return 30;}
	
	public EnumType getWoodType(int meta)
    {
        return null;
    }
	@Override
	public List<ItemStack> onSheared(ItemStack item, IBlockAccess world, BlockPos pos, int fortune) 
	{
		return NonNullList.withSize(1, new ItemStack(this, 1, world.getBlockState(pos).getValue(VARIANT).getMeta()));
	}
	@Override
	public Item getItemDropped(IBlockState state, Random rand, int fortune)
    {
		int meta = this.getMetaFromState(state);
		Item stack = Item.getItemFromBlock(BlockInit.sapling);
		stack.getMetadata(1);
        return stack;
    }
	@Override
	 public int quantityDropped(Random random)
    {
//        return random.nextInt(20) == 0 ? 1 : 0;
		return 1;
    }
	@Override
	protected BlockStateContainer createBlockState() 
	{
		return new BlockStateContainer(this, new IProperty[] {VARIANT,DECAYABLE,CHECK_DECAY});
	}
	
	public boolean isOpaqueCube(IBlockState state)
    {
        return false;
    }

    /**
     * Pass true to draw this block using fancy graphics, or false for fast graphics.
     */
 

    @SideOnly(Side.CLIENT)
    public BlockRenderLayer getBlockLayer()
    {
    
        return BlockRenderLayer.CUTOUT_MIPPED;
    }
}