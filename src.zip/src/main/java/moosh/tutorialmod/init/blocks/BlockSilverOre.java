package moosh.tutorialmod.init.blocks;

import java.util.Random;

import net.minecraft.block.Block;
import net.minecraft.block.state.IBlockState;
import net.minecraft.init.Blocks;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;

public class BlockSilverOre extends CustomOre{
 


	

	public static final String name = "silver_ore";
 
    public BlockSilverOre(String name, float hardness, float resistance, int harvestlevel) {
        super(name, hardness, resistance);
        // TODO Auto-generated constructor stub
 
        this.setTickRandomly(true);
        this.setHarvestLevel("pickaxe", harvestlevel);
 
    }

	

	




	



	
	
	
 
}