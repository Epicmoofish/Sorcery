package moosh.tutorialmod.init.blocks;

import javax.annotation.Nullable;

import com.google.common.base.Predicate;

import net.minecraft.block.BlockLog;
import net.minecraft.block.SoundType;
import net.minecraft.block.properties.IProperty;
import net.minecraft.block.properties.PropertyEnum;
import net.minecraft.block.state.BlockStateContainer;
import net.minecraft.block.state.IBlockState;
import net.minecraft.creativetab.CreativeTabs;
import net.minecraft.enchantment.EnchantmentHelper;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.util.DamageSource;
import net.minecraft.util.NonNullList;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;

public class CustomBlockLog extends BlockLog implements IMetaName
{
	public static final PropertyEnum<Planks.EnumType> VARIANT = PropertyEnum.<Planks.EnumType>create("variant", Planks.EnumType.class, new Predicate<Planks.EnumType>()
	{
		public boolean apply(@Nullable Planks.EnumType apply)
		{
			return apply.getMeta() < 2;
		}
	});
	
	public CustomBlockLog(String name) 
	{
		setUnlocalizedName(name);
		setRegistryName(name);
		setSoundType(SoundType.WOOD);
		setDefaultState(this.blockState.getBaseState().withProperty(VARIANT, Planks.EnumType.RAINBOW).withProperty(LOG_AXIS, EnumAxis.Y));
	}
//	@Override
//	public void onEntityWalk(World worldIn, BlockPos pos, Entity entityIn) {
//		// TODO Auto-generated method stub
//		IBlockState state = worldIn.getBlockState(pos);
//		
//		int t = ((Planks.EnumType)state.getValue(VARIANT)).getMeta();
//if (t == 1){
//        if (!entityIn.isImmuneToFire() && entityIn instanceof EntityLivingBase && !EnchantmentHelper.hasFrostWalkerEnchantment((EntityLivingBase)entityIn))
//        {
//            entityIn.attackEntityFrom(DamageSource.HOT_FLOOR, 1.0F);
//        }
//
//		super.onEntityWalk(worldIn, pos, entityIn);
//}
//	}
	@Override
	public void getSubBlocks(CreativeTabs itemIn, NonNullList<ItemStack> items) 
	{
		for(Planks.EnumType Planks$enumtype : Planks.EnumType.values())
		{
			items.add(new ItemStack(this, 1, Planks$enumtype.getMeta()));
		}
	}
	
	@Override
	public IBlockState getStateFromMeta(int meta) 
	{
		IBlockState state = this.getDefaultState().withProperty(VARIANT, Planks.EnumType.byMetadata((meta & 1) % 2));
		
		switch(meta & 6)
		{
		case 0:
			state = state.withProperty(LOG_AXIS, EnumAxis.Y);
			break;
			
		case 2:
			state = state.withProperty(LOG_AXIS, EnumAxis.X);
			break;
			
		case 4:
			state = state.withProperty(LOG_AXIS, EnumAxis.Z);
			break;
			
		default:
			state = state.withProperty(LOG_AXIS, EnumAxis.NONE);
		}
		
		return state;
	}
	
	@SuppressWarnings("incomplete-switch")
	@Override
	public int getMetaFromState(IBlockState state) 
	{
		int i = 0;
		i = i | ((Planks.EnumType)state.getValue(VARIANT)).getMeta();
		
		switch((BlockLog.EnumAxis)state.getValue(LOG_AXIS))
		{
		case X:
			i |= 2;
			break;
			
		case Y:
			i |= 4;
			break;
			
		case Z:
			i |= 6;
		}
		
		return i;
	}
	
	@Override
	protected BlockStateContainer createBlockState() 
	{
		return new BlockStateContainer(this, new IProperty[] {VARIANT,LOG_AXIS});
	}
	
	@Override
	protected ItemStack getSilkTouchDrop(IBlockState state) 
	{
		return new ItemStack(Item.getItemFromBlock(this), 1, ((Planks.EnumType)state.getValue(VARIANT)).getMeta());
	}
	
	@Override
	public int damageDropped(IBlockState state) 
	{
		return ((Planks.EnumType)state.getValue(VARIANT)).getMeta();
	}
	
	@Override
	public String getSpecialName(ItemStack stack) 
	{
		return Planks.EnumType.values()[stack.getItemDamage()].getName();
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
}