package moosh.tutorialmod.init.blocks;

import net.minecraft.item.ItemStack;

public interface IMetaName
{
	public String getSpecialName(ItemStack stack);
}