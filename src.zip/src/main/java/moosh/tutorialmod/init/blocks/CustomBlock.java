package moosh.tutorialmod.init.blocks;

import moosh.tutorialmod.TutorialMod;
import net.minecraft.block.Block;
import net.minecraft.block.material.Material;
import net.minecraft.creativetab.CreativeTabs;

public class CustomBlock extends Block{
	
	public CustomBlock(String name, float hardness, float resistance, int harvestlevel) {
		
        super(Material.ROCK);
        // TODO Auto-generated constructor stub
 
        this.setUnlocalizedName(name);
        this.setCreativeTab(CreativeTabs.BUILDING_BLOCKS);
setHardness(hardness);
        this.setRegistryName(name);
        setResistance(resistance);
        this.setHarvestLevel("pickaxe", harvestlevel);
 
    }
}
