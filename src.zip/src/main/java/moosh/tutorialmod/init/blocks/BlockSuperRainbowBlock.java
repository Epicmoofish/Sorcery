package moosh.tutorialmod.init.blocks;



 
import java.util.Random;

import moosh.tutorialmod.init.ItemInit;
import net.minecraft.block.state.IBlockState;
import net.minecraft.item.Item;
 
public class BlockSuperRainbowBlock extends BlockRainbow{
 
    public static final String name = "super_rainbow_block";
 
    public BlockSuperRainbowBlock(String name, float hardness, float resistance, int harvestlevel) {
        super(name, hardness, resistance);
        // TODO Auto-generated constructor stub
 
     
        this.setHarvestLevel("pickaxe", harvestlevel);
 
    }




	



	
	
	
 
}