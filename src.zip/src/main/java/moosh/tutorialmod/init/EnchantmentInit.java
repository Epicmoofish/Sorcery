package moosh.tutorialmod.init;

import java.util.ArrayList;
import java.util.List;

import moosh.tutorialmod.TutorialMod;
import moosh.tutorialmod.init.enchantments.EnchantmentAutoSmelt;
import moosh.tutorialmod.init.enchantments.EnchantmentPoisoned;
import net.minecraft.enchantment.Enchantment;
import net.minecraftforge.fml.common.Mod;
@Mod.EventBusSubscriber(modid=TutorialMod.MODID)
public class EnchantmentInit {
	public static final List<Enchantment> ENCHANTMENTS = new ArrayList<Enchantment>();
	
	public static final Enchantment POISONED = new EnchantmentPoisoned();
	public static final Enchantment AUTOSMELT = new EnchantmentAutoSmelt();
	
	
	}
