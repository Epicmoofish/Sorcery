package moosh.tutorialmod.init.items;




import moosh.tutorialmod.TutorialMod;
import net.minecraft.creativetab.CreativeTabs;
import net.minecraft.entity.item.EntityItem;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.init.Items;
import net.minecraft.item.ItemSimpleFoiled;
import net.minecraft.item.ItemStack;
import net.minecraft.world.World;

public class ItemFireOrb extends ItemSimpleFoiled{

	
	public final String name = "fire_orb";
	public ItemFireOrb(){
		super();
		
		setUnlocalizedName(TutorialMod.MODID + "_" + this.name);
		this.setCreativeTab(CreativeTabs.MISC);
		this.maxStackSize = 1;
		setRegistryName(name);


	
	
	
		
		
	}
	

}
