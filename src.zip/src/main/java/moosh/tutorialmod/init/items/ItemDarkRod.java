package moosh.tutorialmod.init.items;

import java.util.Random;

import moosh.tutorialmod.TutorialMod;
import net.minecraft.creativetab.CreativeTabs;
import net.minecraft.entity.Entity;
import net.minecraft.item.ItemFishingRod;
import net.minecraft.item.ItemStack;
import net.minecraft.world.World;

public class ItemDarkRod extends ItemFishingRod
{
	public final String name = "dark_fishing_rod";
public ItemDarkRod()
{
	super ();
setUnlocalizedName(TutorialMod.MODID + "_" + this.name);
setRegistryName(name);
setCreativeTab(CreativeTabs.TOOLS);
this.setMaxDamage(256);


}
@Override
public void onUpdate(ItemStack stack, World worldIn, Entity entityIn, int itemSlot, boolean isSelected) {
	// TODO Auto-generated method stub
	if (stack.getItemDamage() != 0){

	this.setDamage(stack, stack.getItemDamage()-1);
	}
	super.onUpdate(stack, worldIn, entityIn, itemSlot, isSelected);
}

}