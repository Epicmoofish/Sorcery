package moosh.tutorialmod.init.items;

import java.util.List;

import moosh.tutorialmod.TutorialMod;
import moosh.tutorialmod.init.BlockInit;
import moosh.tutorialmod.init.ItemInit;
import net.minecraft.block.state.IBlockState;
import net.minecraft.client.util.ITooltipFlag;
import net.minecraft.creativetab.CreativeTabs;
import net.minecraft.enchantment.Enchantment;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.item.ItemPickaxe;
import net.minecraft.item.ItemStack;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;

public class DarkPick extends ItemPickaxe
{
	
	@Override
	public void addInformation(ItemStack stack, World worldIn, List<String> tooltip, ITooltipFlag flagIn) {
		// TODO Auto-generated method stub
		if (stack.isItemEnchantable() == true){
			stack.addEnchantment(Enchantment.getEnchantmentByID(35), 25);
		}
		super.addInformation(stack, worldIn, tooltip, flagIn);
	}

	public final String name = "dark_pickaxe";
public DarkPick()
{
	super (ItemInit.toolMaterialDark);
setUnlocalizedName(TutorialMod.MODID + "_" + this.name);
setRegistryName(name);
setCreativeTab(CreativeTabs.TOOLS);
}

@Override
public boolean onBlockDestroyed(ItemStack stack, World worldIn, IBlockState state, BlockPos pos,
		EntityLivingBase entityLiving) {
	// TODO Auto-generated method stub
//	if (entityLiving.isSneaking()== true && state.getBlock() != BlockInit.rainbow_ore){
//	if (state.getBlock().canHarvestBlock(worldIn, pos, (EntityPlayer) entityLiving)){
//	BlockPos pos2;
//
//
//	IBlockState a;
//	int x = pos.getX();
//	int y = pos.getY();
//	int z = pos.getZ();
//	int x2 = x;
//	int y2 = y;
//	int z2 = z;
//	for (int c=1; c<8; c++){
//	y2=y+c-2;
//		pos2 = new BlockPos(x2,y2,z2);
//		a = worldIn.getBlockState(pos2);
//	for (int b=1; b<8; b++){
//		z2=z+b-4;
//		pos2 = new BlockPos(x2,y2,z2);
//		a = worldIn.getBlockState(pos2);
//	for (int i=1; i<8; i++){
//	x2=x+i-4;
//		pos2 = new BlockPos(x2,y2,z2);
//		a = worldIn.getBlockState(pos2);
//
//		
//		if (worldIn.getBlockState(pos2) == state){
//			stack.damageItem(1, entityLiving);
//			 
//worldIn.destroyBlock(pos2, true);
//			
//		}} x2=x;
//	} z2=z;
//	}
//	y2=y;
//		}
	
//
//	}
	if (entityLiving.isSneaking()== true){
	ItemInit.superBreak(7, worldIn, state, pos, entityLiving, stack);
	}
	return super.onBlockDestroyed(stack, worldIn, state, pos, entityLiving);
}

@Override
public void onUpdate(ItemStack stack, World worldIn, Entity entityIn, int itemSlot, boolean isSelected) {
	// TODO Auto-generated method stub
	if (stack.isItemEnchantable() == true){
		stack.addEnchantment(Enchantment.getEnchantmentByID(35), 25);
	}
	if (stack.getItemDamage() != 0){

	this.setDamage(stack, stack.getItemDamage()-5);
	}

	if (stack.getItemDamage() < 0){

		this.setDamage(stack, 0);
		}
	
	super.onUpdate(stack, worldIn, entityIn, itemSlot, isSelected);
}



}