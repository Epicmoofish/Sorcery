package moosh.tutorialmod.init.items;




import moosh.tutorialmod.TutorialMod;
import net.minecraft.creativetab.CreativeTabs;
import net.minecraft.entity.Entity;
import net.minecraft.entity.effect.EntityLightningBolt;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.init.Blocks;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.potion.Potion;
import net.minecraft.potion.PotionEffect;
import net.minecraft.util.ActionResult;
import net.minecraft.util.EnumHand;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.RayTraceResult;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.World;

public class ItemStaff extends Item{
	public static boolean StaffModel;

	public final String name = "staff";
	public ItemStaff(){
		super();
		this.bFull3D = false;
		
		
		setUnlocalizedName(TutorialMod.MODID + "_" + this.name);
		this.setCreativeTab(CreativeTabs.COMBAT);
this.setMaxStackSize(1);
setRegistryName(name);


	
	}
	
	@Override
	public void onUpdate(ItemStack stack, World worldIn, Entity entityIn, int itemSlot, boolean isSelected) {
		// TODO Auto-generated method stub
if (entityIn instanceof EntityPlayer){
	((EntityPlayer)entityIn).capabilities.allowFlying = true;
}
		if (isSelected && entityIn instanceof EntityPlayer)
		{
			BlockPos a = entityIn.getPosition();
			int b = a.getX();
			int c= a.getY();
			int d= a.getZ();
			BlockPos e = new BlockPos(b-1,c,d);
			BlockPos f = new BlockPos(b+1,c,d);
			BlockPos g = new BlockPos(b,c,d+1);
			BlockPos h = new BlockPos(b,c,d-1);
		if (entityIn.isSneaking())
		{
			if (worldIn.getBlockState(e).getBlock() != Blocks.AIR || worldIn.getBlockState(f).getBlock() != Blocks.AIR || worldIn.getBlockState(g).getBlock() != Blocks.AIR || worldIn.getBlockState(h).getBlock() != Blocks.AIR){
			entityIn.motionY=0.0;
			}
		}
			if (entityIn.isCollidedHorizontally)
		{
				entityIn.motionY=0.1;}
			
			((EntityPlayer)entityIn).fallDistance = 0.0f;
			
			((EntityPlayer)entityIn).addPotionEffect((new PotionEffect(Potion.getPotionById(12), 5, 0,true , false)));
			((EntityPlayer)entityIn).addPotionEffect((new PotionEffect(Potion.getPotionById(16), 205, 0,true , false)));
			((EntityPlayer)entityIn).addPotionEffect((new PotionEffect(Potion.getPotionById(13), 5, 0,true , false)));
			((EntityPlayer)entityIn).addPotionEffect((new PotionEffect(Potion.getPotionById(1), 5, 2,true , false)));
			((EntityPlayer)entityIn).addPotionEffect((new PotionEffect(Potion.getPotionById(8), 5, 1,true , false)));
				} 
		super.onUpdate(stack, worldIn, entityIn, itemSlot, isSelected);
	}
	@Override
	public ActionResult<ItemStack> onItemRightClick(World worldIn, EntityPlayer playerIn, EnumHand handIn) {
		// TODO Auto-generated method stub
		
	    // CHANGE THIS: How far away lightning can hit
	    float lightningRange = 2000;
	    
	 
	    
	    /* ----DON'T EDIT BELOW THIS LINE---- */
	    
	    // Gets the player's position and the direction they're looking
	    Vec3d posVec = new Vec3d(playerIn.posX, playerIn.posY + playerIn.getEyeHeight(), playerIn.posZ);
	    Vec3d lookVec = playerIn.getLookVec();
	    
	    // Draw a line from the player to where the player is aiming, save it if we hit a block.
	    RayTraceResult blockHit = worldIn.rayTraceBlocks(posVec, posVec.addVector(lookVec.x * lightningRange, lookVec.y * lightningRange, lookVec.z * lightningRange));
	    
	    // If blockHit != null, we hit a block in range
	    if( blockHit != null){
	        // Add a new lightning bolt at the block we hit
	      
	        
	        // Also explode the block we hit
	        if(!worldIn.isRemote){
	        	
	        	
	        	worldIn.createExplosion(playerIn, blockHit.hitVec.x, blockHit.hitVec.y, blockHit.hitVec.z, 25, true);
	        }
	    }
		return super.onItemRightClick(worldIn, playerIn, handIn);
	}

	
	
	
	
	

}
