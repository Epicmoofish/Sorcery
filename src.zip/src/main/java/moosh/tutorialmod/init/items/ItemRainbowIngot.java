package moosh.tutorialmod.init.items;

import moosh.tutorialmod.TutorialMod;
import net.minecraft.creativetab.CreativeTabs;
import net.minecraft.item.Item;
import net.minecraft.item.Item.ToolMaterial;

public class ItemRainbowIngot extends Item
{
	public final String name = "rainbow_ingot";
public ItemRainbowIngot()
{
	super ();
setUnlocalizedName(TutorialMod.MODID + "_" + this.name);
setRegistryName(name);
setCreativeTab(CreativeTabs.MISC);
}

}