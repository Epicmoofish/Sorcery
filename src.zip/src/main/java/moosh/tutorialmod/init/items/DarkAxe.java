package moosh.tutorialmod.init.items;

import moosh.tutorialmod.TutorialMod;
import moosh.tutorialmod.init.ItemInit;
import net.minecraft.block.state.IBlockState;
import net.minecraft.creativetab.CreativeTabs;
import net.minecraft.enchantment.Enchantment;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.init.Blocks;
import net.minecraft.item.ItemStack;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;

public class DarkAxe extends ItemAxey
{
	public final String name = "dark_axe";
public DarkAxe()
{
	super (ItemInit.toolMaterialDark);
setUnlocalizedName(TutorialMod.MODID + "_" + this.name);
setRegistryName(name);
setCreativeTab(CreativeTabs.TOOLS);
this.attackSpeed = -3.0f;
}
@Override
public boolean onBlockDestroyed(ItemStack stack, World worldIn, IBlockState state, BlockPos pos,
		EntityLivingBase entityLiving) {
	// TODO Auto-generated method stub
	
	if (state.getBlock() == Blocks.LOG || state.getBlock() == Blocks.LOG2){
	BlockPos pos2;


	IBlockState a;
	int x = pos.getX();
	int y = pos.getY();
	int z = pos.getZ();
	int x2 = x;
	int y2 = y;
	int z2 = z;
	for (int c=1; c<21; c++){
	y2=y+c-2;
		pos2 = new BlockPos(x2,y2,z2);
		a = worldIn.getBlockState(pos2);
	for (int b=1; b<4; b++){
		z2=z+b-2;
		pos2 = new BlockPos(x2,y2,z2);
		a = worldIn.getBlockState(pos2);
	for (int i=1; i<4; i++){
	x2=x+i-2;
		pos2 = new BlockPos(x2,y2,z2);
		a = worldIn.getBlockState(pos2);

		
		if (worldIn.getBlockState(pos2) == state){
			stack.damageItem(1, entityLiving);
			 
worldIn.destroyBlock(pos2, true);
			
		}} x2=x;
	} z2=z;
	}
	y2=y;
		}

	
	return super.onBlockDestroyed(stack, worldIn, state, pos, entityLiving);
}
@Override
public void onUpdate(ItemStack stack, World worldIn, Entity entityIn, int itemSlot, boolean isSelected) {
	// TODO Auto-generated method stub
	if (stack.getItemDamage() >= 3){

	this.setDamage(stack, stack.getItemDamage()-3);
	}
	if (stack.getItemDamage() == 2){

	this.setDamage(stack, stack.getItemDamage()-2);
	}
	if (stack.getItemDamage() == 1){

	this.setDamage(stack, stack.getItemDamage()-1);
	}
	if (stack.getItemDamage() < 0){

		this.setDamage(stack, 0);
		}

	super.onUpdate(stack, worldIn, entityIn, itemSlot, isSelected);
}


}