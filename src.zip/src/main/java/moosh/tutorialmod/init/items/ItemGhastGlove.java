package moosh.tutorialmod.init.items;




import moosh.tutorialmod.TutorialMod;
import moosh.tutorialmod.init.ItemInit;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.entity.projectile.EntityLargeFireball;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.potion.Potion;
import net.minecraft.potion.PotionEffect;
import net.minecraft.util.ActionResult;
import net.minecraft.util.EnumHand;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.World;

public class ItemGhastGlove extends Item{

	
	public final String name = "ghast_glove";
	public ItemGhastGlove(){
		super();
		
		setUnlocalizedName(TutorialMod.MODID + "_" + this.name);
		this.setCreativeTab(ItemInit.tabGlove);
		setRegistryName(name);
this.setMaxStackSize(1);


	}
	@Override
	public ActionResult<ItemStack> onItemRightClick(World worldIn, EntityPlayer playerIn, EnumHand handIn) {
		// TODO Auto-generated method stub
		Vec3d lookVec = playerIn.getLookVec();
		
		if (!worldIn.isRemote){
			EntityLargeFireball fireball3 = new EntityLargeFireball(worldIn, playerIn, 1, 1, 1);
		      fireball3.setPosition(
		         playerIn.posX + lookVec.x * 1,
		         playerIn.posY + lookVec.y * 1 + 1.5,
		    	     playerIn.posZ + lookVec.z * 1);
		    	     fireball3.accelerationX = lookVec.x * 0.2;
		    	      fireball3.accelerationY = lookVec.y * 0.2;
		    	      fireball3.accelerationZ = lookVec.z * 0.2;
		    	      fireball3.explosionPower=1;
		    	      
		    	    	    
		    	    	
		    	   
		    	    
		    	      worldIn.spawnEntity(fireball3);

		}
		
		return super.onItemRightClick(worldIn, playerIn, handIn);
	}
	
	
	@Override
	public void onUpdate(ItemStack stack, World worldIn, Entity entityIn, int itemSlot, boolean isSelected) {
		// TODO Auto-generated method stub
		if (isSelected){
			((EntityPlayer)entityIn).addPotionEffect((new PotionEffect(Potion.getPotionById(12), 5, 0,true , false)));
			
			
		}
		super.onUpdate(stack, worldIn, entityIn, itemSlot, isSelected);
	}
	

}
