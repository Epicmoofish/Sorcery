package moosh.tutorialmod.init.items;

import java.util.List;

import moosh.tutorialmod.TutorialMod;
import moosh.tutorialmod.init.ItemInit;
import net.minecraft.client.util.ITooltipFlag;
import net.minecraft.creativetab.CreativeTabs;
import net.minecraft.enchantment.Enchantment;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.item.ItemStack;
import net.minecraft.item.ItemSword;
import net.minecraft.nbt.NBTTagList;
import net.minecraft.potion.Potion;
import net.minecraft.potion.PotionEffect;
import net.minecraft.world.World;

public class DarkSword extends ItemSword
{
	public final String name = "dark_sword";
public DarkSword()
{
	super (ItemInit.toolMaterialDark);
setUnlocalizedName(TutorialMod.MODID + "_" + this.name);
setRegistryName(name);
setCreativeTab(CreativeTabs.COMBAT);
}





@Override
public void addInformation(ItemStack stack, World worldIn, List<String> tooltip, ITooltipFlag flagIn) {
	// TODO Auto-generated method stub
	
	if (stack.isItemEnchantable() == true){
		
	
	stack.addEnchantment(Enchantment.getEnchantmentByID(21), 25);
	}
	super.addInformation(stack, worldIn, tooltip, flagIn);
}





@Override
public void onUpdate(ItemStack stack, World worldIn, Entity entityIn, int itemSlot, boolean isSelected) {
	// TODO Auto-generated method stub
	if (stack.isItemEnchantable() == true){
		
		
		stack.addEnchantment(Enchantment.getEnchantmentByID(21), 25);
		}
	
	
	

if (stack.getItemDamage() >= 3){

	this.setDamage(stack, stack.getItemDamage()-3);
	}
	if (stack.getItemDamage() == 2){

	this.setDamage(stack, stack.getItemDamage()-2);
	}
	if (stack.getItemDamage() == 1){

	this.setDamage(stack, stack.getItemDamage()-1);
	}
	if (stack.getItemDamage() < 0){

		this.setDamage(stack, 0);
		}
	super.onUpdate(stack, worldIn, entityIn, itemSlot, isSelected);
}



@Override
public boolean hitEntity(ItemStack stack, EntityLivingBase target, EntityLivingBase attacker) {
target.addPotionEffect((new PotionEffect(Potion.getPotionById(20), 200, 1)));
	return super.hitEntity(stack, target, attacker);
}

}