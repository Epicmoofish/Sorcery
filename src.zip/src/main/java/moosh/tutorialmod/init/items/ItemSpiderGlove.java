package moosh.tutorialmod.init.items;




import moosh.tutorialmod.TutorialMod;
import moosh.tutorialmod.init.ItemInit;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.init.Blocks;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;

public class ItemSpiderGlove extends Item{


	public final String name = "spider_glove";
	public ItemSpiderGlove(){
		super();
	
		
		setUnlocalizedName(TutorialMod.MODID + "_" + this.name);
		this.setCreativeTab(ItemInit.tabGlove);
this.setMaxStackSize(1);
setRegistryName(name);


	}
	@Override
	public void onUpdate(ItemStack stack, World worldIn, Entity entityIn, int itemSlot, boolean isSelected) {
		// TODO Auto-generated method stub
		if (isSelected && entityIn instanceof EntityPlayer){
			BlockPos a = entityIn.getPosition();
			int b = a.getX();
			int c= a.getY();
			int d= a.getZ();
			BlockPos e = new BlockPos(b-1,c,d);
			BlockPos f = new BlockPos(b+1,c,d);
			BlockPos g = new BlockPos(b,c,d+1);
			BlockPos h = new BlockPos(b,c,d-1);
		if (entityIn.isSneaking())
		{
			if (worldIn.getBlockState(e).getBlock() != Blocks.AIR || worldIn.getBlockState(f).getBlock() != Blocks.AIR || worldIn.getBlockState(g).getBlock() != Blocks.AIR || worldIn.getBlockState(h).getBlock() != Blocks.AIR){
			entityIn.motionY=0.0;
			}
		}
			if (entityIn.isCollidedHorizontally)
		{
				entityIn.motionY=0.1;}
			}
			
			
		
		
		
		super.onUpdate(stack, worldIn, entityIn, itemSlot, isSelected);
	}
	
	}


		
	
	

		
	
	
