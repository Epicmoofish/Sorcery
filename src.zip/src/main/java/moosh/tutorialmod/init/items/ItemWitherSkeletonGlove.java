package moosh.tutorialmod.init.items;




import moosh.tutorialmod.TutorialMod;
import moosh.tutorialmod.init.ItemInit;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.potion.Potion;
import net.minecraft.potion.PotionEffect;

public class ItemWitherSkeletonGlove extends Item{


	public final String name = "wither_skeleton_glove";
	public ItemWitherSkeletonGlove(){
		super();
	
		
		setUnlocalizedName(TutorialMod.MODID + "_" + this.name);
		this.setCreativeTab(ItemInit.tabGlove);
this.setMaxStackSize(1);
setRegistryName(name);


	}
	@Override
	public boolean hitEntity(ItemStack stack, EntityLivingBase target, EntityLivingBase attacker) {
		// TODO Auto-generated method stub
		if (target instanceof EntityLivingBase){
			target.addPotionEffect((new PotionEffect(Potion.getPotionById(20), 200, 1)));
		
	}
	
			
			
		return super.hitEntity(stack, target, attacker);
		
		
		
	
	}}


		
	
	

		
	
	
