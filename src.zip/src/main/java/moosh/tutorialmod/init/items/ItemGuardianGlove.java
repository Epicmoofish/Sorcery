package moosh.tutorialmod.init.items;




import moosh.tutorialmod.TutorialMod;
import moosh.tutorialmod.init.ItemInit;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.potion.Potion;
import net.minecraft.potion.PotionEffect;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;

public class ItemGuardianGlove extends Item{


	public final String name = "guardian_glove";
	public ItemGuardianGlove(){
		super();
	
		
		setUnlocalizedName(TutorialMod.MODID + "_" + this.name);
		this.setCreativeTab(ItemInit.tabGlove);
this.setMaxStackSize(1);
setRegistryName(name);

	}
	private EntityPlayer a;
	private BlockPos b;
	 private float field_175482_b;
	    private float field_175484_c;
	    private float field_175483_bk;
	    private float field_175485_bl;
	    private int field_175479_bo;
	    private boolean field_175480_bp;
	    private float field_175486_bm;

	private int tickCounter;
	@Override
	public void onUpdate(ItemStack stack, World worldIn, Entity entityIn, int itemSlot, boolean isSelected) {
		// TODO Auto-generated method stub
		if (isSelected){

			((EntityPlayer)entityIn).addPotionEffect((new PotionEffect(Potion.getPotionById(16), 205, 0,true , false)));
			((EntityPlayer)entityIn).addPotionEffect((new PotionEffect(Potion.getPotionById(13), 5, 0,true , false)));
		}
		
		super.onUpdate(stack, worldIn, entityIn, itemSlot, isSelected);
	}

		// TODO Auto-generated method stub
       
		
	
	
	
		

	

		
	
	
	
	

}
