package moosh.tutorialmod.init.items;

import moosh.tutorialmod.TutorialMod;
import net.minecraft.creativetab.CreativeTabs;
import net.minecraft.item.Item;
import net.minecraft.item.Item.ToolMaterial;

public class ItemSuperRainbowIngot extends Item
{
	public final String name = "super_rainbow_ingot";
public ItemSuperRainbowIngot()
{
	super ();
setUnlocalizedName(TutorialMod.MODID + "_" + this.name);
setRegistryName(name);
setCreativeTab(CreativeTabs.MISC);
}

}