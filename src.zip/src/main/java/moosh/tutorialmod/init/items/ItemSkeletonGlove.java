package moosh.tutorialmod.init.items;




import moosh.tutorialmod.TutorialMod;
import moosh.tutorialmod.init.ItemInit;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.entity.projectile.EntityArrow;
import net.minecraft.entity.projectile.EntityTippedArrow;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.util.ActionResult;
import net.minecraft.util.EnumHand;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.World;

public class ItemSkeletonGlove extends Item{

	
	public final String name = "skeleton_glove";
	public ItemSkeletonGlove(){
		super();
		
		setUnlocalizedName(TutorialMod.MODID + "_" + this.name);
		this.setCreativeTab(ItemInit.tabGlove);
this.setMaxStackSize(1);
setRegistryName(name);


	}
	@Override
	public ActionResult<ItemStack> onItemRightClick(World worldIn, EntityPlayer playerIn, EnumHand handIn) {
		// TODO Auto-generated method stub
		Vec3d lookVec = playerIn.getLookVec();
		
		if (!worldIn.isRemote){
	
			EntityTippedArrow fireball3 = new EntityTippedArrow(worldIn, playerIn);
		      fireball3.setPosition(
		    	     playerIn.posX + lookVec.x * 1,
		    	     playerIn.posY + lookVec.y * 1 + 1.5,
		    	     playerIn.posZ + lookVec.z * 1);
		    	      fireball3.motionX = lookVec.x * 3.0;
		    	      fireball3.motionY = lookVec.y * 3.0;
		    	      fireball3.motionZ = lookVec.z * 3.0;
		    	      fireball3.pickupStatus = EntityArrow.PickupStatus.CREATIVE_ONLY;
		    	     
		    	      
		    	    	    
		    	    	
		    	   
		    	    
		    	      worldIn.spawnEntity(fireball3);

		}
		
		return super.onItemRightClick(worldIn, playerIn, handIn);
	}
	
	
	

}
