package moosh.tutorialmod.init.items;




import moosh.tutorialmod.TutorialMod;
import moosh.tutorialmod.init.ItemInit;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.potion.Potion;
import net.minecraft.potion.PotionEffect;
import net.minecraft.world.World;

public class ItemMagmaCubeGlove extends Item{

	
	public final String name = "magma_cube_glove";
	public ItemMagmaCubeGlove(){
		super();
		
		setUnlocalizedName(TutorialMod.MODID + "_" + this.name);
		this.setCreativeTab(ItemInit.tabGlove);
this.setMaxStackSize(1);
setRegistryName(name);


	}
	
	
	@Override
	public void onUpdate(ItemStack stack, World worldIn, Entity entityIn, int itemSlot, boolean isSelected) {
		// TODO Auto-generated method stub
		if (isSelected){
			((EntityPlayer)entityIn).addPotionEffect((new PotionEffect(Potion.getPotionById(12), 5, 0,true , false)));
			((EntityPlayer)entityIn).addPotionEffect((new PotionEffect(Potion.getPotionById(8), 5, 2,true , false)));
		}
		super.onUpdate(stack, worldIn, entityIn, itemSlot, isSelected);
	}
	

}
