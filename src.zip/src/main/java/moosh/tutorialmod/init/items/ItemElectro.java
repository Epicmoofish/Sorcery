package moosh.tutorialmod.init.items;

import moosh.tutorialmod.TutorialMod;
import net.minecraft.creativetab.CreativeTabs;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.effect.EntityLightningBolt;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.potion.Potion;
import net.minecraft.potion.PotionEffect;
import net.minecraft.util.ActionResult;
import net.minecraft.util.EnumHand;
import net.minecraft.util.math.RayTraceResult;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.World;

public class ItemElectro extends Item
{
	public final String name = "zapper";
public ItemElectro()
{
	super ();
setUnlocalizedName(TutorialMod.MODID + "_" + this.name);
setRegistryName(name);
setCreativeTab(CreativeTabs.COMBAT);
this.maxStackSize = 1;
this.setMaxDamage(495);
}
@Override
public boolean hitEntity(ItemStack stack, EntityLivingBase target, EntityLivingBase attacker) {
	// TODO Auto-generated method stub
	target.addPotionEffect((new PotionEffect(Potion.getPotionById(8), 600, 128, true, false)));
	target.addPotionEffect((new PotionEffect(Potion.getPotionById(2), 600, 100,true, false)));
	stack.damageItem(5, attacker);
	return super.hitEntity(stack, target, attacker);
	
}
@Override
public ActionResult<ItemStack> onItemRightClick(World worldIn, EntityPlayer playerIn, EnumHand handIn) {
	// TODO Auto-generated method stub
	
    // CHANGE THIS: How far away lightning can hit
    float lightningRange = 2000;
    
 
    
    /* ----DON'T EDIT BELOW THIS LINE---- */
    
    // Gets the player's position and the direction they're looking
    Vec3d posVec = new Vec3d(playerIn.posX, playerIn.posY + playerIn.getEyeHeight(), playerIn.posZ);
    Vec3d lookVec = playerIn.getLookVec();
    
    // Draw a line from the player to where the player is aiming, save it if we hit a block.
    RayTraceResult blockHit = worldIn.rayTraceBlocks(posVec, posVec.addVector(lookVec.x * lightningRange, lookVec.y * lightningRange, lookVec.z * lightningRange));
    
    // If blockHit != null, we hit a block in range
    if( blockHit != null){
        // Add a new lightning bolt at the block we hit
      
        
        // Also explode the block we hit
        if(!worldIn.isRemote){
        	playerIn.getHeldItemMainhand().damageItem(5, playerIn);
        	
        	worldIn.addWeatherEffect(new EntityLightningBolt(worldIn, blockHit.hitVec.x, blockHit.hitVec.y, blockHit.hitVec.z, false));
        }
    }
	return super.onItemRightClick(worldIn, playerIn, handIn);
}
}