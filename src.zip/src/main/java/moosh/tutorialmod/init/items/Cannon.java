package moosh.tutorialmod.init.items;

import moosh.tutorialmod.TutorialMod;
import moosh.tutorialmod.init.ItemInit;
import moosh.tutorialmod.init.entities.EntityCannonball;
import net.minecraft.creativetab.CreativeTabs;
import net.minecraft.enchantment.Enchantment;
import net.minecraft.enchantment.EnchantmentHelper;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.entity.projectile.EntityLargeFireball;
import net.minecraft.item.Item;
import net.minecraft.item.ItemArrow;
import net.minecraft.item.ItemStack;
import net.minecraft.util.ActionResult;
import net.minecraft.util.EnumHand;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.World;

public class Cannon extends Item{

	public final String name = "cannon";

	public Cannon(){
		super();

		setUnlocalizedName(TutorialMod.MODID + "_" + this.name);
		setRegistryName(name);
		this.setCreativeTab(CreativeTabs.COMBAT);
this.setMaxStackSize(1);


	}
	  protected boolean isArrow(ItemStack stack)
	    {
	        return stack.getItem() instanceof ItemCannonball;
	    }
	private ItemStack findAmmo(EntityPlayer player)
    {
        if (this.isArrow(player.getHeldItem(EnumHand.OFF_HAND)))
        {
            return player.getHeldItem(EnumHand.OFF_HAND);
        }
        else if (this.isArrow(player.getHeldItem(EnumHand.MAIN_HAND)))
        {
            return player.getHeldItem(EnumHand.MAIN_HAND);
        }
        else
        {
            for (int i = 0; i < player.inventory.getSizeInventory(); ++i)
            {
                ItemStack itemstack = player.inventory.getStackInSlot(i);

                if (this.isArrow(itemstack))
                {
                    return itemstack;
                }
            }

            return ItemStack.EMPTY;
        }
    }
	@Override
	public ActionResult<ItemStack> onItemRightClick(World worldIn, EntityPlayer playerIn, EnumHand handIn) {
		// TODO Auto-generated method stub
		Vec3d lookVec = playerIn.getLookVec();
		
		// Play a sound when you fire
 
			
		ItemStack itemstack = this.findAmmo(playerIn);
			if (itemstack.getItem() == ItemInit.cannonball || playerIn.capabilities.isCreativeMode)
	        {
				
				
	  
		
		
		if (!worldIn.isRemote)
		{
			EntityCannonball fireball3 = new EntityCannonball(worldIn, playerIn);
		      fireball3.setPosition(
		    	     playerIn.posX + lookVec.x * 2,
		    	     playerIn.posY + lookVec.y * 2 + 1.5,
		    	     playerIn.posZ + lookVec.z * 2);
		    	      fireball3.motionX = lookVec.x * 2.2;
		    	      fireball3.motionY = lookVec.y * 2.2;
		    	      fireball3.motionZ = lookVec.z * 2.2;

		    	      
		    	    	    
		    	    	
		    	   
		    	    
		    	      worldIn.spawnEntity(fireball3);
		    	  	if (!playerIn.capabilities.isCreativeMode)
			        {
			            
						itemstack.shrink(1);
			        }
		    	    
		}} 
		
			
			
  
	
	
		
	return super.onItemRightClick(worldIn, playerIn, handIn);
}


	

}
