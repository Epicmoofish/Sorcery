package moosh.tutorialmod.init.items;

import moosh.tutorialmod.TutorialMod;
import moosh.tutorialmod.init.ItemInit;
import net.minecraft.block.state.IBlockState;
import net.minecraft.creativetab.CreativeTabs;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.init.Blocks;
import net.minecraft.item.ItemHoe;
import net.minecraft.item.ItemStack;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;

public class DarkHoe extends ItemHoe
{
	public final String name = "dark_hoe";
public DarkHoe()
{
	super (ItemInit.toolMaterialDark);
setUnlocalizedName(TutorialMod.MODID + "_" + this.name);
setRegistryName(name);
setCreativeTab(CreativeTabs.TOOLS);
}

@Override
public void onUpdate(ItemStack stack, World worldIn, Entity entityIn, int itemSlot, boolean isSelected) {
	// TODO Auto-generated method stub
	if (stack.getItemDamage() >= 3){

	this.setDamage(stack, stack.getItemDamage()-3);
	}
	if (stack.getItemDamage() == 2){

	this.setDamage(stack, stack.getItemDamage()-2);
	}
	if (stack.getItemDamage() == 1){

	this.setDamage(stack, stack.getItemDamage()-1);
	}
	if (stack.getItemDamage() < 0){

		this.setDamage(stack, 0);
		}

	super.onUpdate(stack, worldIn, entityIn, itemSlot, isSelected);
}


}