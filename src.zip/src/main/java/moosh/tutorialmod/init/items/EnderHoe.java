package moosh.tutorialmod.init.items;

import moosh.tutorialmod.TutorialMod;
import moosh.tutorialmod.init.ItemInit;
import net.minecraft.block.Block;
import net.minecraft.block.BlockDirt;
import net.minecraft.block.state.IBlockState;
import net.minecraft.creativetab.CreativeTabs;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.init.Blocks;
import net.minecraft.item.ItemHoe;
import net.minecraft.item.ItemStack;
import net.minecraft.util.EnumActionResult;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.EnumHand;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;

public class EnderHoe extends ItemHoe
{
	public final String name = "ender_hoe";
public EnderHoe()
{
	super (ItemInit.toolMaterialEnder);
setUnlocalizedName(TutorialMod.MODID + "_" + this.name);
setRegistryName(name);
setCreativeTab(CreativeTabs.TOOLS);
}
public boolean getIsRepairable(ItemStack toRepair, ItemStack repair)
{
    return repair.getItem() == ItemInit.enderIngot;
}
 

}
