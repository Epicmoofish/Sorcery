package moosh.tutorialmod.init.items;




import moosh.tutorialmod.TutorialMod;
import moosh.tutorialmod.init.ItemInit;
import net.minecraft.enchantment.EnchantmentHelper;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.MoverType;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.potion.Potion;
import net.minecraft.potion.PotionEffect;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.MathHelper;
import net.minecraft.world.World;

public class ItemSquidGlove extends Item{


	public final String name = "squid_glove";
	public ItemSquidGlove(){
		super();
	
		
		setUnlocalizedName(TutorialMod.MODID + "_" + this.name);
		this.setCreativeTab(ItemInit.tabGlove);
this.setMaxStackSize(1);
setRegistryName(name);

	}
	private EntityPlayer a;
	private BlockPos b;
	 private float field_175482_b;
	    private float field_175484_c;
	    private float field_175483_bk;
	    private float field_175485_bl;
	    private int field_175479_bo;
	    private boolean field_175480_bp;
	    private float field_175486_bm;

	private int tickCounter;
	@Override
	public void onUpdate(ItemStack stack, World worldIn, Entity entityIn, int itemSlot, boolean isSelected) {
		// TODO Auto-generated method stub

		if (isSelected){

			((EntityPlayer)entityIn).addPotionEffect((new PotionEffect(Potion.getPotionById(13), 5, 0,true , false)));
		}
		
		super.onUpdate(stack, worldIn, entityIn, itemSlot, isSelected);
	}
	public static void water(EntityLivingBase player, boolean selected){
		if (player.isInWater()){
		{
            double d0 = player.posY;
            float f1 = 0.4F;
            float f2 = 0.02F;
            float f3 = 3.0F;

            if (f3 > 3.0F)
            {
                f3 = 3.0F;
            }

            if (!player.onGround)
            {
                f3 *= 0.5F;
            }

            if (f3 > 0.0F)
            {
                f1 += (0.54600006F - f1) * f3 / 3.0F;
            
                f2 += (player.getAIMoveSpeed() - f2) * f3 / 3.0F;
            }
            
            float p_191986_3_= player.moveForward;
			float p_191986_1_ = player.moveStrafing;
			float p_191986_2_ = player.moveVertical;
			//player.moveRelative(p_191986_1_, p_191986_2_, p_191986_3_, f2);
	
            player.move(MoverType.SELF, player.motionX, player.motionY, player.motionZ);
            player.motionX *= (double)f1;
            player.motionY *= 0.800000011920929D;
            player.motionZ *= (double)f1;

            if (!player.hasNoGravity())
            {
                player.motionY -= 0.02D;
            }

            if (player.isCollidedHorizontally && player.isOffsetPositionInLiquid(player.motionX, player.motionY + 0.6000000238418579D - player.posY + d0, player.motionZ))
            {
                player.motionY = 0.30000001192092896D;
            }
        }
    }

    player.prevLimbSwingAmount = player.limbSwingAmount;
    double d5 = player.posX - player.prevPosX;
    double d7 = player.posZ - player.prevPosZ;
    double d9 = player instanceof net.minecraft.entity.passive.EntityFlying ? player.posY - player.prevPosY : 0.0D;
    float f10 = MathHelper.sqrt(d5 * d5 + d9 * d9 + d7 * d7) * 4.0F;

    if (f10 > 1.0F)
    {
        f10 = 1.0F;
    }

    player.limbSwingAmount += (f10 - player.limbSwingAmount) * 0.4F;
    player.limbSwing += player.limbSwingAmount;
}

		}

		// TODO Auto-generated method stub
       
		
	
	
	
		

	

		
	
	
	
	


