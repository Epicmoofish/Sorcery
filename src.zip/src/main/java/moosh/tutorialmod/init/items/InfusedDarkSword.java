package moosh.tutorialmod.init.items;

import java.util.List;

import moosh.tutorialmod.TutorialMod;
import moosh.tutorialmod.init.ItemInit;
import net.minecraft.block.state.IBlockState;
import net.minecraft.client.util.ITooltipFlag;
import net.minecraft.creativetab.CreativeTabs;
import net.minecraft.enchantment.Enchantment;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.item.ItemStack;
import net.minecraft.item.ItemSword;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.nbt.NBTTagList;
import net.minecraft.potion.Potion;
import net.minecraft.potion.PotionEffect;
import net.minecraft.util.EnumHand;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;

public class InfusedDarkSword extends ItemSwordy
{
	




	public final String name = "infused_sword";
	private int timesHit;
public InfusedDarkSword()
{
	super (ItemInit.toolMaterialDark);
setUnlocalizedName(TutorialMod.MODID + "_" + this.name);
setRegistryName(name);
setCreativeTab(CreativeTabs.COMBAT);
setMaxDamage(1000);


}




public void addHits(int amount, ItemStack stack){
	if (stack.hasTagCompound() && stack.getTagCompound().hasKey("Hits")){
	stack.getTagCompound().setInteger("Hits", stack.getTagCompound().getInteger("Hits") + amount);
	}
	else{
		stack.getTagCompound().setInteger("Hits", amount);
	}
}
@Override
public void onUpdate(ItemStack stack, World worldIn, Entity entityIn, int itemSlot, boolean isSelected) {
	// TODO Auto-generated method stub
	if (stack.isItemEnchantable() == true){
		stack.addEnchantment(Enchantment.getEnchantmentByID(21), 25);
	}
	setDamage(stack, getDamage(stack)- 3);
	String x = stack.getEnchantmentTagList().getStringTagAt(1);
	if (stack.hasTagCompound() && stack.getTagCompound().hasKey("Hits")){
		int x1 = stack.getTagCompound().getInteger("Hits") ;
		if (x1>=40){
		
		((EntityLivingBase) entityIn).setHeldItem(EnumHand.MAIN_HAND, new ItemStack(ItemInit.infHammer, 1));
	}}



	super.onUpdate(stack, worldIn, entityIn, itemSlot, isSelected);
}


@Override
public void addInformation(ItemStack stack, World worldIn, List<String> tooltip, ITooltipFlag flagIn) {
	// TODO Auto-generated method stub
	int x = 0;
	if (stack.hasTagCompound() && stack.getTagCompound().hasKey("Hits")){
	x = stack.getTagCompound().getInteger("Hits") ;
	}
	
	int y=40-x;
	
	  
	tooltip.add("You have "+ y + " hits left until this turns into the rainbow hammer!");

	if (stack.isItemEnchantable() == true){
		stack.addEnchantment(Enchantment.getEnchantmentByID(21), 25);
	}
	super.addInformation(stack, worldIn, tooltip, flagIn);
}




@Override
public boolean hitEntity(ItemStack stack, EntityLivingBase target, EntityLivingBase attacker) {
	this.addHits(1, stack);

target.addPotionEffect((new PotionEffect(Potion.getPotionById(20), 200, 1)));
	return super.hitEntity(stack, target, attacker);
}

}