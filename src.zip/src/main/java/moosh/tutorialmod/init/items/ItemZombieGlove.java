package moosh.tutorialmod.init.items;




import moosh.tutorialmod.TutorialMod;
import moosh.tutorialmod.init.ItemInit;
import net.minecraft.entity.Entity;
import net.minecraft.entity.monster.EntityZombie;
import net.minecraft.entity.monster.EntityZombieVillager;
import net.minecraft.entity.passive.EntityVillager;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.util.DamageSource;

public class ItemZombieGlove extends Item{


	public final String name = "zombie_glove";
	public ItemZombieGlove(){
		super();
		this.bFull3D = false;
		
		setUnlocalizedName(TutorialMod.MODID + "_" + this.name);
		this.setCreativeTab(ItemInit.tabGlove);
this.setMaxStackSize(1);
setRegistryName(name);
	}
	@Override
	public boolean onLeftClickEntity(ItemStack stack, EntityPlayer player, Entity entity) {
		// TODO Auto-generated method stub
	
		if (entity instanceof EntityVillager)
		{
			int x = ((EntityVillager)entity).getProfession();

			if (!entity.getEntityWorld().isRemote){
			entity.setDead();
			EntityZombieVillager zombie = new EntityZombieVillager(entity.getEntityWorld());
			zombie.setPositionAndRotation(
		    	     entity.posX,
		    	     entity.posY,
		    	     entity.posZ,
		    	     entity.rotationYaw,
		    	     entity.rotationPitch
		    	     );
			
			zombie.setProfession(x);
			
			zombie.attackEntityFrom(DamageSource.causePlayerDamage(player), 1);
			zombie.setChild(((EntityVillager) entity).isChild());

			entity.getEntityWorld().spawnEntity(zombie);
			}
		}
		return super.onLeftClickEntity(stack, player, entity);
	}
	
	
	
	

}
