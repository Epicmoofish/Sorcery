package moosh.tutorialmod.init.items;




import moosh.tutorialmod.TutorialMod;
import moosh.tutorialmod.init.ItemInit;
import net.minecraft.block.state.IBlockState;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.init.Blocks;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;

public class ItemSheepGlove extends Item{


	public final String name = "sheep_glove";
	public ItemSheepGlove(){
		super();
	
		
		setUnlocalizedName(TutorialMod.MODID + "_" + this.name);
		this.setCreativeTab(ItemInit.tabGlove);
this.setMaxStackSize(1);
setRegistryName(name);


	}
	@Override
	public void onUpdate(ItemStack stack, World worldIn, Entity entityIn, int itemSlot, boolean isSelected) {
		// TODO Auto-generated method stub
		if (!worldIn.isRemote) {
		if (isSelected && entityIn instanceof EntityPlayer){
			BlockPos a = entityIn.getPosition();
			int b = a.getX();
			int c= a.getY();
			int d= a.getZ();
			BlockPos e = new BlockPos(b,c-1,d);
			IBlockState hi = Blocks.DIRT.getDefaultState();
			if (worldIn.getBlockState(e).getBlock() == Blocks.GRASS && ((EntityPlayer)entityIn).getFoodStats().needFood() && ((EntityPlayer)entityIn).isSneaking()) {
				worldIn.setBlockState(e, hi);
			((EntityPlayer)entityIn).getFoodStats().addStats(2, 1);
		}}
		}
			
		
		
		
		super.onUpdate(stack, worldIn, entityIn, itemSlot, isSelected);
	}
	
	}


		
	
	

		
	
	
