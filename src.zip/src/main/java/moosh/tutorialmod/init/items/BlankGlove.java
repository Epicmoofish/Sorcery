package moosh.tutorialmod.init.items;




import moosh.tutorialmod.TutorialMod;
import moosh.tutorialmod.init.ItemInit;
import net.minecraft.enchantment.EnchantmentHelper;
import net.minecraft.entity.Entity;
import net.minecraft.entity.monster.EntityBlaze;
import net.minecraft.entity.monster.EntityEnderman;
import net.minecraft.entity.monster.EntityEndermite;
import net.minecraft.entity.monster.EntityGhast;
import net.minecraft.entity.monster.EntityGuardian;
import net.minecraft.entity.monster.EntityIronGolem;
import net.minecraft.entity.monster.EntityMagmaCube;
import net.minecraft.entity.monster.EntitySkeleton;
import net.minecraft.entity.monster.EntitySpider;
import net.minecraft.entity.monster.EntityWitherSkeleton;
import net.minecraft.entity.monster.EntityZombie;
import net.minecraft.entity.passive.EntityCow;
import net.minecraft.entity.passive.EntityHorse;
import net.minecraft.entity.passive.EntityOcelot;
import net.minecraft.entity.passive.EntityParrot;
import net.minecraft.entity.passive.EntitySheep;
import net.minecraft.entity.passive.EntitySquid;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.util.EnumHand;

public class BlankGlove extends Item{

	
	public final String name = "blank_glove";
	public BlankGlove(){
		super();
		
		setUnlocalizedName(TutorialMod.MODID + "_" + this.name);
		setRegistryName(name);
		this.setCreativeTab(ItemInit.tabGlove);
		
this.setMaxStackSize(1);

	}
	@Override
	public boolean onLeftClickEntity(ItemStack stack, EntityPlayer player, Entity entity) {
		// TODO Auto-generated method stub
		
		if (entity instanceof EntityBlaze)
		{
			
			if (!entity.getEntityWorld().isRemote){
				player.setHeldItem(EnumHand.MAIN_HAND, new ItemStack(ItemInit.blazeGlove, 1));
			}
		}
		if (entity instanceof EntityParrot)
		{
			if (!entity.getEntityWorld().isRemote){
				player.setHeldItem(EnumHand.MAIN_HAND, new ItemStack(ItemInit.batGlove, 1));
			}
		}
		if (entity instanceof EntityEnderman)
		{
			if (!entity.getEntityWorld().isRemote){
				player.setHeldItem(EnumHand.MAIN_HAND, new ItemStack(ItemInit.endermanGlove, 1));
			}
		}
		if (entity instanceof EntityEndermite)
		{
			if (!entity.getEntityWorld().isRemote){
				player.setHeldItem(EnumHand.MAIN_HAND, new ItemStack(ItemInit.endermiteGlove, 1));
			}
		}
		if (entity instanceof EntityWitherSkeleton)
		{
			if (!entity.getEntityWorld().isRemote){
				player.setHeldItem(EnumHand.MAIN_HAND, new ItemStack(ItemInit.witherskeleGlove, 1));
			}
		}
		if (entity instanceof EntityMagmaCube)
		{
			if (!entity.getEntityWorld().isRemote){
				player.setHeldItem(EnumHand.MAIN_HAND, new ItemStack(ItemInit.magmaGlove, 1));
			}
		}
		if (entity instanceof EntityGhast)
		{
			if (!entity.getEntityWorld().isRemote){
				player.setHeldItem(EnumHand.MAIN_HAND, new ItemStack(ItemInit.ghastGlove, 1));
			}
		}
		if (entity instanceof EntitySkeleton)
		{
			if (!entity.getEntityWorld().isRemote){
				player.setHeldItem(EnumHand.MAIN_HAND, new ItemStack(ItemInit.skeletonGlove, 1));
			}
		}
		if (entity instanceof EntitySpider)
		{
			if (!entity.getEntityWorld().isRemote){
				player.setHeldItem(EnumHand.MAIN_HAND, new ItemStack(ItemInit.spiderGlove, 1));
			}
		}
		if (entity instanceof EntityGuardian)
		{
			if (!entity.getEntityWorld().isRemote){
				player.setHeldItem(EnumHand.MAIN_HAND, new ItemStack(ItemInit.guardianGlove, 1));
			}
		}
		if (entity instanceof EntityZombie)
		{
			if (!entity.getEntityWorld().isRemote){
				player.setHeldItem(EnumHand.MAIN_HAND, new ItemStack(ItemInit.zombieGlove, 1));
			}
		}
		if (entity instanceof EntitySquid)
		{
			if (!entity.getEntityWorld().isRemote){
				player.setHeldItem(EnumHand.MAIN_HAND, new ItemStack(ItemInit.squidGlove, 1));
			}
		}
		if (entity instanceof EntitySheep)
		{
			if (!entity.getEntityWorld().isRemote){
				player.setHeldItem(EnumHand.MAIN_HAND, new ItemStack(ItemInit.sheepGlove, 1));
			}
		}
		if (entity instanceof EntityIronGolem)
		{
			if (!entity.getEntityWorld().isRemote){
				player.setHeldItem(EnumHand.MAIN_HAND, new ItemStack(ItemInit.golemGlove, 1));
			}
		}
		if (entity instanceof EntityCow)
		{
			if (!entity.getEntityWorld().isRemote){
				player.setHeldItem(EnumHand.MAIN_HAND, new ItemStack(ItemInit.cowGlove, 1));
			}
		}
		if (entity instanceof EntityHorse)
		{
			if (!entity.getEntityWorld().isRemote){
				player.setHeldItem(EnumHand.MAIN_HAND, new ItemStack(ItemInit.horseGlove, 1));
			}
		}
		if (entity instanceof EntityOcelot)
		{
			if (!entity.getEntityWorld().isRemote){
				player.setHeldItem(EnumHand.MAIN_HAND, new ItemStack(ItemInit.ocelotGlove, 1));
			}
		}	
		return super.onLeftClickEntity(stack, player, entity);
	}

	//@Override
	//public ItemStack onItemRightClick(ItemStack itemStackIn, World worldIn, EntityPlayer playerIn) {
		// TODO Auto-generated method stub
		//if (!worldIn.isRemote){
		//if (playerIn.inventory.hasItem(Items.blaze_rod))
			
		//{
				
					//itemStackIn.setItem(ItemMod.itemBlazeGlove);
				//}
			//}
		
		//return super.onItemRightClick(itemStackIn, worldIn, playerIn);
	//}
	

}
