package moosh.tutorialmod.init.items;




import java.util.Random;

import moosh.tutorialmod.TutorialMod;
import moosh.tutorialmod.init.ItemInit;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.potion.Potion;
import net.minecraft.potion.PotionEffect;
import net.minecraft.util.EnumParticleTypes;
import net.minecraft.world.World;

public class ItemEndermiteGlove extends Item{

	
	public final String name = "endermite_glove";
	public ItemEndermiteGlove(){
		super();
		
		setUnlocalizedName(TutorialMod.MODID + "_" + this.name);
		this.setCreativeTab(ItemInit.tabGlove);
		this.maxStackSize = 1;
		setRegistryName(name);


	
	
	
		
		
	}
	@Override
	public void onUpdate(ItemStack stack, World worldIn, Entity entityIn, int itemSlot, boolean isSelected) {
		// TODO Auto-generated method stub
		if (isSelected){
			((EntityPlayer)entityIn).addPotionEffect((new PotionEffect(Potion.getPotionById(14), 5, 0,true , false)));
		Random ran = new Random();
		double x = ran.nextDouble();
		double y = ran.nextDouble();
		double z = ran.nextDouble();
		double x2 = ran.nextDouble();
		double y2 = ran.nextDouble();
		double z2 = ran.nextDouble();
		double x3 = ran.nextDouble();
		double y3 = ran.nextDouble();
		double z3 = ran.nextDouble();
	
		worldIn.spawnParticle(EnumParticleTypes.PORTAL, entityIn.posX+x-0.5, entityIn.posY+y-0.5, entityIn.posZ+z-0.5, 0, 0, 0, 0);
		worldIn.spawnParticle(EnumParticleTypes.PORTAL, entityIn.posX+x2-0.5, entityIn.posY+y2-0.5, entityIn.posZ+z2-0.5, 0, 0, 0, 0);
		worldIn.spawnParticle(EnumParticleTypes.PORTAL, entityIn.posX+x3-0.5, entityIn.posY+y3-0.5, entityIn.posZ+z3-0.5, 0, 0, 0, 0);
		}
		
		super.onUpdate(stack, worldIn, entityIn, itemSlot, isSelected);
	}
	

}
