package moosh.tutorialmod.init.items;

import moosh.tutorialmod.TutorialMod;
import moosh.tutorialmod.init.ItemInit;
import net.minecraft.creativetab.CreativeTabs;
import net.minecraft.item.ItemSpade;
import net.minecraft.item.ItemStack;

public class EnderShovel extends ItemSpade
{
	public final String name = "ender_shovel";
public EnderShovel()
{
	super (ItemInit.toolMaterialEnder);
setUnlocalizedName(TutorialMod.MODID + "_" + this.name);
setRegistryName(name);
setCreativeTab(CreativeTabs.TOOLS);
}
public boolean getIsRepairable(ItemStack toRepair, ItemStack repair)
{
    return repair.getItem() == ItemInit.enderIngot;
}
}