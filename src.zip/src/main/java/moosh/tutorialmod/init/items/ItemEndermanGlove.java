package moosh.tutorialmod.init.items;




import moosh.tutorialmod.TutorialMod;
import moosh.tutorialmod.init.ItemInit;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.util.ActionResult;
import net.minecraft.util.EnumHand;
import net.minecraft.util.math.RayTraceResult;
import net.minecraft.util.math.Vec3d;
import net.minecraft.util.text.ITextComponent;
import net.minecraft.util.text.TextComponentString;
import net.minecraft.util.text.TextFormatting;
import net.minecraft.world.World;

public class ItemEndermanGlove extends Item{


	public final String name = "enderman_glove";
	public ItemEndermanGlove(){
		super();
	
		
		setUnlocalizedName(TutorialMod.MODID + "_" + this.name);
		this.setCreativeTab(ItemInit.tabGlove);
this.setMaxStackSize(1);
setRegistryName(name);

	}
	@Override
	public ActionResult<ItemStack> onItemRightClick(World worldIn, EntityPlayer playerIn, EnumHand handIn) {
		// TODO Auto-generated method stub// CHANGE THIS: How far away lightning can hit
        float lightningRange = 60;
        
        // CHANGE THIS: Explosion Size

        // CHANGE THIS: Does it destroy blocks?
    
        
        /* ----DON'T EDIT BELOW THIS LINE---- */
        
        // Gets the player's position and the direction they're looking
        Vec3d posVec = new Vec3d(playerIn.posX, playerIn.posY + playerIn.getEyeHeight(), playerIn.posZ);
        Vec3d lookVec = playerIn.getLookVec();
        
        // Draw a line from the player to where the player is aiming, save it if we hit a block.
        RayTraceResult blockHit = worldIn.rayTraceBlocks(posVec, posVec.addVector(lookVec.x * lightningRange, lookVec.y * lightningRange, lookVec.z * lightningRange));
        
        // If blockHit != null, we hit a block in range
        if( blockHit != null){
            // Add a new lightning bolt at the block we hit
   
            
            // Also explode the block we hit
            if(!worldIn.isRemote){
            	
           playerIn.setPositionAndUpdate(blockHit.hitVec.x, blockHit.hitVec.y, blockHit.hitVec.z);
            	
            }
        }else
        	if(!worldIn.isRemote){
        		
        		ITextComponent component = new TextComponentString("Enderman Glove: Block undetected or out of range!");
        		component.getStyle().setColor(TextFormatting.DARK_PURPLE);
   		     playerIn.sendMessage(component);

        	}

        return super.onItemRightClick(worldIn, playerIn, handIn);
	}
	
	
		
	
	

		
	
	
	
	

}
