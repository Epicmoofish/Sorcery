package moosh.tutorialmod.init.items;

import moosh.tutorialmod.TutorialMod;
import net.minecraft.creativetab.CreativeTabs;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.entity.projectile.EntitySmallFireball;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.util.ActionResult;
import net.minecraft.util.EnumHand;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.World;

public class FlameFist extends Item
{
	public final String name = "flaming_fist";
public FlameFist()
{
	super ();
setUnlocalizedName(TutorialMod.MODID + "_" + this.name);
setRegistryName(name);
setCreativeTab(CreativeTabs.COMBAT);
this.setMaxDamage(50);
}
@Override
public ActionResult<ItemStack> onItemRightClick(World worldIn, EntityPlayer playerIn, EnumHand handIn) {
	// TODO Auto-generated method stub
	Vec3d lookVec = playerIn.getLookVec();
	if (!worldIn.isRemote)
	{
	EntitySmallFireball fireball3 = new EntitySmallFireball(worldIn, playerIn, 1, 1, 1);
	playerIn.getHeldItemMainhand().damageItem(1, playerIn);
  
	fireball3.setPosition(
    	     playerIn.posX + lookVec.x * 1,
    	     playerIn.posY + lookVec.y * 1 + 1.5,
    	     playerIn.posZ + lookVec.z * 1);
    	      fireball3.accelerationX = lookVec.x * 0.2;
    	      fireball3.accelerationY = lookVec.y * 0.2;
    	      fireball3.accelerationZ = lookVec.z * 0.2;
    	      
    	    	    
    	    	
    	   
    	    
    	      worldIn.spawnEntity(fireball3);
	}
	return super.onItemRightClick(worldIn, playerIn, handIn);
}
}