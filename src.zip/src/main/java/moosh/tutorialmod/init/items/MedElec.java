package moosh.tutorialmod.init.items;

import moosh.tutorialmod.TutorialMod;
import net.minecraft.creativetab.CreativeTabs;
import net.minecraft.entity.effect.EntityLightningBolt;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.util.ActionResult;
import net.minecraft.util.EnumHand;
import net.minecraft.util.math.RayTraceResult;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.World;

public class MedElec extends Item
{
	public final String name = "medium_electric_charge";
public MedElec()
{
	super ();
setUnlocalizedName(TutorialMod.MODID + "_" + this.name);
setRegistryName(name);
setCreativeTab(CreativeTabs.MISC);
}

}