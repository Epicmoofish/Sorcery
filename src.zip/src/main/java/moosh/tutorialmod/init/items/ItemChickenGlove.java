package moosh.tutorialmod.init.items;




import moosh.tutorialmod.TutorialMod;
import moosh.tutorialmod.init.ItemInit;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.world.World;

public class ItemChickenGlove extends Item{


	public final String name = "chicken_glove";
	public ItemChickenGlove(){
		super();
	
		
		setUnlocalizedName(TutorialMod.MODID + "_" + this.name);
		this.setCreativeTab(ItemInit.tabGlove);
this.setMaxStackSize(1);
setRegistryName(name);

	}
	

	private int tickCounter;
	@Override
	public void onUpdate(ItemStack stack, World worldIn, Entity entityIn, int itemSlot, boolean isSelected) {
		// TODO Auto-generated method stub
		if (entityIn instanceof EntityPlayer){
	if (isSelected && !((EntityPlayer)entityIn).capabilities.isFlying && entityIn.fallDistance >= 1.0){
		 entityIn.fallDistance = 1.0F;
	entityIn.motionY = -0.04;	
		
	}
		}
		super.onUpdate(stack, worldIn, entityIn, itemSlot, isSelected);
	}

		// TODO Auto-generated method stub
       
		
	
	
	
		

	

		
	
	
	
	

}
