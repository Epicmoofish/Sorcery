package moosh.tutorialmod.init.items;

import java.util.List;

import moosh.tutorialmod.TutorialMod;
import moosh.tutorialmod.init.BlockInit;
import moosh.tutorialmod.init.ItemInit;
import net.minecraft.block.state.IBlockState;
import net.minecraft.client.util.ITooltipFlag;
import net.minecraft.creativetab.CreativeTabs;
import net.minecraft.enchantment.Enchantment;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.item.ItemPickaxe;
import net.minecraft.item.ItemStack;
import net.minecraft.util.EnumHand;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;

public class ItemDarkHammer extends ItemHammer
{
	
	public final String name = "infused_hammer";
	private int timesHit;
public ItemDarkHammer()
{
	super (ItemInit.toolMaterialRainbow);
setUnlocalizedName(TutorialMod.MODID + "_" + this.name);
setRegistryName(name);

setCreativeTab(CreativeTabs.TOOLS);
this.setMaxDamage(1500);

}




@Override
public boolean hitEntity(ItemStack stack, EntityLivingBase target, EntityLivingBase attacker) {
	// TODO Auto-generated method stub
addHits(10, stack);


	return super.hitEntity(stack, target, attacker);
}
@Override
public void addInformation(ItemStack stack, World worldIn, List<String> tooltip, ITooltipFlag flagIn) {
	// TODO Auto-generated method stub
	if (stack.isItemEnchantable() == true){
		
	
	stack.addEnchantment(Enchantment.getEnchantmentByID(35), 100);
	stack.addEnchantment(Enchantment.getEnchantmentByID(21), 100);
	
	}
	int x = 0;
	if (stack.hasTagCompound() && stack.getTagCompound().hasKey("Hits")){
	x = stack.getTagCompound().getInteger("Hits") ;
	}
	int y=50-x;
int z = y/10;
	  int a = (z*10-y)*-1;
	  if (!(a<=0)){
	  
	tooltip.add("You have "+ z +"."+ a + " hits left until this turns back into the dark sword!");
	  } else {
			tooltip.add("You have "+ z + " hits left until this turns back into the dark sword!");
	  }
	super.addInformation(stack, worldIn, tooltip, flagIn);
}


public void addHits(int amount, ItemStack stack){
	if (stack.hasTagCompound() && stack.getTagCompound().hasKey("Hits")){
	stack.getTagCompound().setInteger("Hits", stack.getTagCompound().getInteger("Hits") + amount);
	}
	else{
		stack.getTagCompound().setInteger("Hits", amount);
	}
}
@Override
public void onUpdate(ItemStack stack, World worldIn, Entity entityIn, int itemSlot, boolean isSelected) {
	// TODO Auto-generated method stub
	setDamage(stack, getDamage(stack)- 3000);
	if (stack.isItemEnchantable() == true){
		
		
	stack.addEnchantment(Enchantment.getEnchantmentByID(35), 100);
	stack.addEnchantment(Enchantment.getEnchantmentByID(21), 100);

	}
	if (stack.hasTagCompound() && stack.getTagCompound().hasKey("Hits")){
		int x1 = stack.getTagCompound().getInteger("Hits") ;
		if (x1>=50){
		
		((EntityLivingBase) entityIn).setHeldItem(EnumHand.MAIN_HAND, new ItemStack(ItemInit.infdarkSword, 1));
	}}


	super.onUpdate(stack, worldIn, entityIn, itemSlot, isSelected);
	
}

@Override
public boolean onBlockDestroyed(ItemStack stack, World worldIn, IBlockState state, BlockPos pos,
		EntityLivingBase entityLiving) {
	// TODO Auto-generated method stub
		//stack.damageItem(1, entityLiving);	if (!worldIn.isRemote){

//
	//}
	addHits(1, stack);
	if (entityLiving.isSneaking()== true && state.getBlock() != BlockInit.rainbow_ore){
	if (state.getBlock().canHarvestBlock(worldIn, pos, (EntityPlayer) entityLiving)){


		if (!worldIn.isRemote){
		addHits(9, stack);
			}

	BlockPos pos2;


	IBlockState a;
	int x = pos.getX();
	int y = pos.getY();
	int z = pos.getZ();
	int x2 = x;
	int y2 = y;
	int z2 = z;
	for (int c=1; c<16; c++){
	y2=y+c-2;
		pos2 = new BlockPos(x2,y2,z2);
		a = worldIn.getBlockState(pos2);
	for (int b=1; b<16; b++){
		z2=z+b-8;
		pos2 = new BlockPos(x2,y2,z2);
		a = worldIn.getBlockState(pos2);
	for (int i=1; i<16; i++){
	x2=x+i-8;
		pos2 = new BlockPos(x2,y2,z2);
		a = worldIn.getBlockState(pos2);

		
		if (worldIn.getBlockState(pos2) == state){
			
			 
worldIn.destroyBlock(pos2, true);
			
		}} x2=x;
	} z2=z;
	}
	y2=y;
		}

	}

	return super.onBlockDestroyed(stack, worldIn, state, pos, entityLiving);
}


}