package moosh.tutorialmod.init.items;




import moosh.tutorialmod.TutorialMod;
import moosh.tutorialmod.init.ItemInit;
import net.minecraft.entity.item.EntityItem;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.init.Items;
import net.minecraft.item.Item;
import net.minecraft.item.ItemBucket;
import net.minecraft.item.ItemStack;
import net.minecraft.util.ActionResult;
import net.minecraft.util.EnumHand;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.World;

public class ItemCowGlove extends Item{

	
	public final String name = "cow_glove";
	public ItemCowGlove(){
		super();
		
		setUnlocalizedName(TutorialMod.MODID + "_" + this.name);
		this.setCreativeTab(ItemInit.tabGlove);
this.setMaxStackSize(1);
setRegistryName(name);


	}
	protected boolean isArrow(ItemStack stack)
    {
        return stack.getItem() instanceof ItemBucket;
    }
private ItemStack findAmmo(EntityPlayer player)
{
    if (this.isArrow(player.getHeldItem(EnumHand.OFF_HAND)))
    {
        return player.getHeldItem(EnumHand.OFF_HAND);
    }
    else if (this.isArrow(player.getHeldItem(EnumHand.MAIN_HAND)))
    {
        return player.getHeldItem(EnumHand.MAIN_HAND);
    }
    else
    {
        for (int i = 0; i < player.inventory.getSizeInventory(); ++i)
        {
            ItemStack itemstack = player.inventory.getStackInSlot(i);

            if (this.isArrow(itemstack))
            {
                return itemstack;
            }
        }

        return ItemStack.EMPTY;
    }
}
@Override
public ActionResult<ItemStack> onItemRightClick(World worldIn, EntityPlayer playerIn, EnumHand handIn) {
	// TODO Auto-generated method stub
	Vec3d lookVec = playerIn.getLookVec();
	
	// Play a sound when you fire

		
	ItemStack itemstack = this.findAmmo(playerIn);
		if (itemstack.getItem() == Items.BUCKET)
        {
			
			
  
	
	
	if (!worldIn.isRemote)
	{
		itemstack.shrink(1);
		
playerIn.inventory.addItemStackToInventory(new ItemStack(Items.MILK_BUCKET));
	    	  	
		            
					
		        
	    	    
	}}
		return super.onItemRightClick(worldIn, playerIn, handIn);
}}
	
	


