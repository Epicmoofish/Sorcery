package moosh.tutorialmod.init.items;

import java.awt.event.ActionListener;

import javax.swing.Timer;

import moosh.tutorialmod.TutorialMod;
import net.minecraft.creativetab.CreativeTabs;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.init.Items;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.util.ActionResult;
import net.minecraft.util.DamageSource;
import net.minecraft.util.EnumHand;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.text.ITextComponent;
import net.minecraft.util.text.TextComponentString;
import net.minecraft.world.World;

public class EndCharge extends Item
{
	public final String name = "ender_charge";
public EndCharge()
{
	super ();
setUnlocalizedName(TutorialMod.MODID + "_" + this.name);
setRegistryName(name);
setCreativeTab(CreativeTabs.MISC);
this.setMaxDamage(1);
}
@Override
public ActionResult<ItemStack> onItemRightClick(World worldIn, EntityPlayer playerIn, EnumHand handIn) {
	// TODO Auto-generated method stub
	if (!worldIn.isRemote){
		ItemStack itemStackIn = playerIn.getHeldItem(handIn);
		itemStackIn.damageItem(2, playerIn);
		     final double x2 =  playerIn.posX;
		     final double y2 =  playerIn.posY;
		     final double z2 =  playerIn.posZ;
		     final long x =  Math.round(x2);
		     final long y =  Math.round(y2);
		     final long z =  Math.round(z2);
		    
		     ITextComponent component = new TextComponentString("Ender Charge detonated at X: " +x + " Y:"+y+ " Z:"+ z);
		     
		     playerIn.sendMessage(component);
		    
			    
		     
		     ActionListener action = new ActionListener()
			 {
		    	 
			     
			 	@Override
			 	public void actionPerformed(java.awt.event.ActionEvent e) {
			 		
			 		// TODO Auto-generated method stub
			 
			 		playerIn.addExperience(playerIn.experienceLevel*40);
			 		if (playerIn.inventory.hasItemStack(new ItemStack(Items.TOTEM_OF_UNDYING))){
			 		playerIn.attemptTeleport(x, y, z);
			 		playerIn.attackEntityFrom(DamageSource.causeExplosionDamage(playerIn), 40);
			 		}
			 		worldIn.createExplosion(playerIn, x, y, z, 10, true);
			 	
			 	
			 	}
			 };
			 Timer timer2 = new Timer(0, action);
			    timer2.setRepeats(false);
			    timer2.setInitialDelay(15000);
			    timer2.start();
	}
	
	return super.onItemRightClick(worldIn, playerIn, handIn);
}

}