package moosh.tutorialmod.init.items;

import java.util.List;

import moosh.tutorialmod.TutorialMod;
import moosh.tutorialmod.init.ItemInit;
import net.minecraft.client.util.ITooltipFlag;
import net.minecraft.creativetab.CreativeTabs;
import net.minecraft.enchantment.Enchantment;
import net.minecraft.enchantment.EnchantmentHelper;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.entity.projectile.EntityArrow;
import net.minecraft.init.Enchantments;
import net.minecraft.init.Items;
import net.minecraft.init.SoundEvents;
import net.minecraft.item.ItemArrow;
import net.minecraft.item.ItemBow;
import net.minecraft.item.ItemStack;
import net.minecraft.item.ItemSword;
import net.minecraft.nbt.NBTTagList;
import net.minecraft.potion.Potion;
import net.minecraft.potion.PotionEffect;
import net.minecraft.stats.StatList;
import net.minecraft.util.ActionResult;
import net.minecraft.util.EnumActionResult;
import net.minecraft.util.EnumHand;
import net.minecraft.util.SoundCategory;
import net.minecraft.world.World;

public class RainbowBow extends ItemBow
{
	public final String name = "rainbow_bow";
public RainbowBow()
{
	super ();
setUnlocalizedName(TutorialMod.MODID + "_" + this.name);
setRegistryName(name);
setCreativeTab(CreativeTabs.COMBAT);

}





@Override
public void addInformation(ItemStack stack, World worldIn, List<String> tooltip, ITooltipFlag flagIn) {
	// TODO Auto-generated method stub
	tooltip.add("Can be spam fired!!");
	if (stack.isItemEnchantable() == true){
		
	
	stack.addEnchantment(Enchantment.getEnchantmentByID(21), 100);
	}
	super.addInformation(stack, worldIn, tooltip, flagIn);
}


@Override
public ActionResult<ItemStack> onItemRightClick(World worldIn, EntityPlayer playerIn, EnumHand handIn)
{
    ItemStack itemstack = playerIn.getHeldItem(handIn);
    boolean flag = true;

    ActionResult<ItemStack> ret = net.minecraftforge.event.ForgeEventFactory.onArrowNock(itemstack, worldIn, playerIn, handIn, flag);
    if (ret != null) return ret;

    {
        playerIn.setActiveHand(handIn);
        return new ActionResult<ItemStack>(EnumActionResult.SUCCESS, itemstack);
    }
}

@Override
public void onUpdate(ItemStack stack, World worldIn, Entity entityIn, int itemSlot, boolean isSelected) {
	// TODO Auto-generated method stub
	
	if (stack.isItemEnchantable() == true){
		
		
		stack.addEnchantment(Enchantment.getEnchantmentByID(21), 100);
		}
	

if (stack.getItemDamage() >= 3){

	this.setDamage(stack, stack.getItemDamage()-3);
	}
	if (stack.getItemDamage() == 2){

	this.setDamage(stack, stack.getItemDamage()-2);
	}
	if (stack.getItemDamage() == 1){

	this.setDamage(stack, stack.getItemDamage()-1);
	}
	if (stack.getItemDamage() < 0){

		this.setDamage(stack, 0);
		}
	super.onUpdate(stack, worldIn, entityIn, itemSlot, isSelected);
}




private ItemStack findAmmo(EntityPlayer player)
{
    if (this.isArrow(player.getHeldItem(EnumHand.OFF_HAND)))
    {
        return player.getHeldItem(EnumHand.OFF_HAND);
    }
    else if (this.isArrow(player.getHeldItem(EnumHand.MAIN_HAND)))
    {
        return player.getHeldItem(EnumHand.MAIN_HAND);
    }
    else
    {
        for (int i = 0; i < player.inventory.getSizeInventory(); ++i)
        {
            ItemStack itemstack = player.inventory.getStackInSlot(i);

            if (this.isArrow(itemstack))
            {
                return itemstack;
            }
        }
        ItemStack itemstack = new ItemStack(Items.ARROW,1);
        return itemstack;
    }
}

protected boolean isArrow(ItemStack stack)
{
    return stack.getItem() instanceof ItemArrow;
}
@Override
public void onPlayerStoppedUsing(ItemStack stack, World worldIn, EntityLivingBase entityLiving, int timeLeft)
{
    if (entityLiving instanceof EntityPlayer)
    {
        EntityPlayer entityplayer = (EntityPlayer)entityLiving;
        boolean flag = entityplayer.capabilities.isCreativeMode || EnchantmentHelper.getEnchantmentLevel(Enchantments.INFINITY, stack) > 0;
        ItemStack itemstack = this.findAmmo(entityplayer);

        int i = this.getMaxItemUseDuration(stack);
        i = net.minecraftforge.event.ForgeEventFactory.onArrowLoose(stack, worldIn, entityplayer, i, !itemstack.isEmpty() || flag);
        if (i < 0) return;
        if (itemstack.isEmpty())
        {
            itemstack = new ItemStack(Items.ARROW);
        }
        if (!itemstack.isEmpty() || flag)
        {
            if (itemstack.isEmpty())
            {
                itemstack = new ItemStack(Items.ARROW);
            }

            float f = getArrowVelocity(i);

            if ((double)f >= 0.1D)
            {
                boolean flag1 = entityplayer.capabilities.isCreativeMode || (itemstack.getItem() == Items.ARROW);
if (EnchantmentHelper.getEnchantmentLevel(Enchantments.INFINITY, stack) > 0) {
	flag1=true;
}
                if (!worldIn.isRemote)
                {
                	ItemStack itemstack2 = itemstack;
                	if(itemstack.isEmpty()){
                		itemstack2 = new ItemStack(Items.ARROW);
                	}
                    ItemArrow itemarrow = (ItemArrow)(itemstack2.getItem() instanceof ItemArrow ? itemstack.getItem() : Items.ARROW);
                    EntityArrow entityarrow = itemarrow.createArrow(worldIn, itemstack, entityplayer);
                    entityarrow.setDamage(20);
                    entityarrow.setAim(entityplayer, entityplayer.rotationPitch, entityplayer.rotationYaw, 0.0F, f * 3.0F, 1.0F);

                    if (f == 1.0F)
                    {
                        entityarrow.setIsCritical(true);
                    }

                    int j = EnchantmentHelper.getEnchantmentLevel(Enchantments.POWER, stack);
                   
                    if (j > 0)
                    {
                        entityarrow.setDamage(entityarrow.getDamage() + (double)j * 0.5D + 0.5D);
                    }

                    int k = EnchantmentHelper.getEnchantmentLevel(Enchantments.PUNCH, stack);

                    if (k > 0)
                    {
                        entityarrow.setKnockbackStrength(k);
                    }

                    //if (EnchantmentHelper.getEnchantmentLevel(Enchantments.FLAME, stack) > 0)
                 //   {
                        entityarrow.setFire(100);
                  //  }

                    stack.damageItem(1, entityplayer);

                    if (flag1 || entityplayer.capabilities.isCreativeMode && (itemstack.getItem() == Items.SPECTRAL_ARROW || itemstack.getItem() == Items.TIPPED_ARROW))
                    {
                        entityarrow.pickupStatus = EntityArrow.PickupStatus.CREATIVE_ONLY;
                    }

                    worldIn.spawnEntity(entityarrow);
                }

                worldIn.playSound((EntityPlayer)null, entityplayer.posX, entityplayer.posY, entityplayer.posZ, SoundEvents.ENTITY_ARROW_SHOOT, SoundCategory.PLAYERS, 1.0F, 1.0F / (itemRand.nextFloat() * 0.4F + 1.2F) + f * 0.5F);

                if (!flag1 && !entityplayer.capabilities.isCreativeMode)
                {
                    itemstack.shrink(1);

                    if (itemstack.isEmpty())
                    {
                        entityplayer.inventory.deleteStack(itemstack);
                    }
                }

                entityplayer.addStat(StatList.getObjectUseStats(this));
            }
        }
    }
}






}