package moosh.tutorialmod.init.items;

import moosh.tutorialmod.TutorialMod;
import net.minecraft.creativetab.CreativeTabs;
import net.minecraft.item.Item;

public class ItemBasic extends Item
{
	
public ItemBasic(String name, CreativeTabs tab, int size)
{
	
	super ();
	
setUnlocalizedName(TutorialMod.MODID + "_" + name);
setRegistryName(name);
setCreativeTab(tab);
setMaxStackSize(size);
}




}