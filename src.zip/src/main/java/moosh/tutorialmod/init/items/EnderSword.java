package moosh.tutorialmod.init.items;

import java.awt.event.ActionListener;

import javax.swing.Timer;

import moosh.tutorialmod.TutorialMod;
import moosh.tutorialmod.init.ItemInit;
import net.minecraft.creativetab.CreativeTabs;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.item.ItemStack;
import net.minecraft.item.ItemSword;
import net.minecraft.util.EnumParticleTypes;
import net.minecraft.world.World;

public class EnderSword extends ItemSword
{
	public final String name = "ender_sword";
public EnderSword()
{
	super (ItemInit.toolMaterialEnder);
setUnlocalizedName(TutorialMod.MODID + "_" + this.name);
setRegistryName(name);
setCreativeTab(CreativeTabs.COMBAT);
}

public boolean getIsRepairable(ItemStack toRepair, ItemStack repair)
{
    return repair.getItem() == ItemInit.enderIngot;
}

@Override
public boolean hitEntity(ItemStack stack, EntityLivingBase target, EntityLivingBase attacker) {
	// TODO Auto-generated method stub
	double x = target.posX;
	double y = target.posY;
	double z = target.posZ;
	ActionListener action = new ActionListener()
	 {
   	 
	     
	 	@Override
	 	public void actionPerformed(java.awt.event.ActionEvent e) {
	 		
	 		// TODO Auto-generated method stub
	 World world = target.getEntityWorld();
	 world.spawnParticle(EnumParticleTypes.PORTAL, target.posX, target.posY, target.posZ, 1, 1, 1);
	 		target.attemptTeleport(x, y, z);
	 		
	 		
	 	
	 	
	 	}
	 };
	 Timer timer2 = new Timer(0, action);
	    timer2.setRepeats(false);
	    timer2.setInitialDelay(250);
	    timer2.start();
	return super.hitEntity(stack, target, attacker);
}


}