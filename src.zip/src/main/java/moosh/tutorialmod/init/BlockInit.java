
package moosh.tutorialmod.init;
 
import moosh.tutorialmod.TutorialMod;
import moosh.tutorialmod.init.blocks.BlockDarkOre;
import moosh.tutorialmod.init.blocks.BlockElectrumOre;
import moosh.tutorialmod.init.blocks.BlockEnderBlock;
import moosh.tutorialmod.init.blocks.BlockEnderOre;
import moosh.tutorialmod.init.blocks.BlockRainbowBlock;
import moosh.tutorialmod.init.blocks.BlockRainbowButton;
import moosh.tutorialmod.init.blocks.BlockRainbowOre;
import moosh.tutorialmod.init.blocks.BlockSilverOre;
import moosh.tutorialmod.init.blocks.BlockSuperRainbowBlock;
import moosh.tutorialmod.init.blocks.CustomBlock;
import moosh.tutorialmod.init.blocks.CustomBlockLeaves;
import moosh.tutorialmod.init.blocks.CustomBlockLog;
import moosh.tutorialmod.init.blocks.CustomBlockSapling;
import moosh.tutorialmod.init.blocks.DarkQuartzBlock;
import moosh.tutorialmod.init.blocks.ItemBlockVariants;
import moosh.tutorialmod.init.blocks.Planks;
import net.minecraft.block.Block;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.block.model.ModelResourceLocation;
import net.minecraft.creativetab.CreativeTabs;
import net.minecraft.item.Item;
import net.minecraft.item.ItemBlock;
import net.minecraft.util.ResourceLocation;
import net.minecraftforge.client.model.ModelLoader;
import net.minecraftforge.fml.common.registry.ForgeRegistries;
//registerBlock(10, "flowing_lava", (new BlockDynamicLiquid(Material.LAVA)).setHardness(100.0F).setLightLevel(1.0F).setUnlocalizedName("lava").disableStats());
//registerBlock(11, "lava", (new BlockStaticLiquid(Material.LAVA)).setHardness(100.0F).setLightLevel(1.0F).setUnlocalizedName("lava").disableStats());
public class BlockInit {
	public static Block tutorial_ore;
	public static Block ender_ore;
	public static Block dark_ore;
	public static Block ender_block;
	public static Block dark_quartz_block;
	
	public static Block rainbow_ore;
	public static Block silver_ore;
	public static Block rainbow_block;
	public static Block super_rainbow_block;
	public static Block planks, leaves, log, sapling, silver_block;
	
	
	public static BlockRainbowButton rainbow_button;

	public static void init()
	{
		tutorial_ore = new BlockElectrumOre("electrum_ore", 3.0f, 4.0f, 3);
		ender_ore = new BlockEnderOre("ender_ore", 3.0f, 4.0f, 2);
		dark_ore = new BlockDarkOre("dark_quartz_ore", 6.0f, 7.0f, 4);
		silver_ore = new BlockSilverOre("silver_ore", 15.0f, 50.0f, 6);
		silver_block = new CustomBlock("silver_block", 20.0f, 60.0f, 6);
		rainbow_ore = new BlockRainbowOre("rainbow_ore", 6.0f, 7.0f, 5).setLightLevel(0.9F);
		rainbow_block = new BlockRainbowBlock("rainbow_block", 6.0f, 7.0f, 4);
			super_rainbow_block = new BlockSuperRainbowBlock("super_rainbow_block", 6.0f, 7.0f, 4).setLightLevel(1.0F);
		ender_block = new BlockEnderBlock("ender_block", 3.0f, 4.0f, 2);
		dark_quartz_block = new DarkQuartzBlock("dark_quartz_block", 3.0f, 4.0f, 2);
		rainbow_button = new BlockRainbowButton("rainbow_button", 2.5f, 4.5f);
		planks = new Planks("planks");
		log = new CustomBlockLog("log");
		leaves = new CustomBlockLeaves("leaves");
		sapling = new CustomBlockSapling("sapling");
		
		
		
		
		

	}

	public static void register()
	{
	registerBlock(tutorial_ore);	
	registerBlock(ender_ore);
	registerBlock(dark_ore);
	registerBlock(dark_quartz_block);
	registerBlock(ender_block);
	registerBlock(rainbow_ore);
	registerBlock(silver_ore);
	registerBlock(silver_block);
	registerBlock(rainbow_block);
	registerBlock(super_rainbow_block);
	



	registerBlockWithVariants(planks, new ItemBlockVariants(planks));
	registerBlockWithVariants(log, new ItemBlockVariants(log));
	registerBlockWithVariants(leaves, new ItemBlockVariants(leaves));
	registerBlockWithVariants(sapling, new ItemBlockVariants(sapling));
	
	
	registerBlockz(rainbow_button);
	
	for(int i = 0; i < Planks.EnumType.values().length; i++)
	{
		registerRenderz(planks, i, "planks_" + Planks.EnumType.values()[i].getName());
		registerRenderz(log, i, "log_" + Planks.EnumType.values()[i].getName());
		registerRenderz(leaves, i, "leaves_" + Planks.EnumType.values()[i].getName());
		registerRenderz(sapling, i, "sapling_" + Planks.EnumType.values()[i].getName());
	}
	
	}
        
	public static void registerBlock(Block block)
        {
        	ForgeRegistries.BLOCKS.register(block);
            block.setCreativeTab(CreativeTabs.BUILDING_BLOCKS);
            ItemBlock item = new ItemBlock(block);
            item.setRegistryName(block.getRegistryName());
            ForgeRegistries.ITEMS.register(item);
            
            ModelLoader.setCustomModelResourceLocation(Item.getItemFromBlock(block), 0, new ModelResourceLocation(block.getRegistryName(), "inventory"));
            
        }
        
        public static void registerBlockz(Block block)
        {
        	ForgeRegistries.BLOCKS.register(block);
            block.setCreativeTab(CreativeTabs.BUILDING_BLOCKS);
            ItemBlock item = new ItemBlock(block);
            item.setRegistryName(block.getRegistryName());
            ForgeRegistries.ITEMS.register(item);
            ModelLoader.setCustomModelResourceLocation(Item.getItemFromBlock(block), 0, new ModelResourceLocation(block.getRegistryName(), "inventory"));
            
        }
        public static void registerBlockWithVariants(Block block, ItemBlock itemblock)
    	{
    		ForgeRegistries.BLOCKS.register(block);
    		block.setCreativeTab(CreativeTabs.BUILDING_BLOCKS);
    		itemblock.setRegistryName(block.getRegistryName());
    		ForgeRegistries.ITEMS.register(itemblock);
    	}
        
        public static void registerOnlyBlock(Block block)
        {
        	ForgeRegistries.BLOCKS.register(block);
            block.setCreativeTab(CreativeTabs.BUILDING_BLOCKS);
        }
    	public static void registerRenders()
    	{
    		registerRender(tutorial_ore);
    		registerRender(ender_ore);
    		registerRender(dark_ore);
    		registerRender(dark_quartz_block);
    		registerRender(ender_block);
    		registerRender(rainbow_ore);
    		registerRender(rainbow_block);
    		registerRender(super_rainbow_block);



  
    	}
    	public static void registerRender(Block block)
    	{
    		Minecraft.getMinecraft().getRenderItem().getItemModelMesher().register(Item.getItemFromBlock(block), 0, new ModelResourceLocation(TutorialMod.MODID + ":" + block.getUnlocalizedName().substring(5)));
    	}
    	public static void registerRenderz(Block block, int meta, String filename)
    	{
    		ModelLoader.setCustomModelResourceLocation(Item.getItemFromBlock(block), meta, new ModelResourceLocation(new ResourceLocation(TutorialMod.MODID, filename), "inventory"));
    	}
 
         
    }
  
   
