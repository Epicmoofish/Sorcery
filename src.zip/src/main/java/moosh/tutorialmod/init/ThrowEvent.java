package moosh.tutorialmod.init;

import java.util.Random;

import moosh.tutorialmod.init.blocks.CustomBlockLeaves;
import moosh.tutorialmod.init.blocks.CustomBlockLog;
import moosh.tutorialmod.init.blocks.Planks;
import moosh.tutorialmod.init.items.ItemStaff;
import moosh.tutorialmod.init.items.ParrotGlove;
import net.minecraft.block.Block;
import net.minecraft.block.state.IBlockState;
import net.minecraft.enchantment.EnchantmentHelper;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.init.Blocks;
import net.minecraft.init.Enchantments;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.crafting.FurnaceRecipes;
import net.minecraft.util.DamageSource;
import net.minecraft.util.EnumHand;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;
import net.minecraftforge.event.entity.living.LivingEvent.LivingUpdateEvent;
import net.minecraftforge.event.world.BlockEvent;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;

public class ThrowEvent
{
	
  public ThrowEvent() {}
  protected boolean isArrow(ItemStack stack)
  {
      return stack.getItem() instanceof ParrotGlove || stack.getItem() instanceof ItemStaff;
  }
private ItemStack findAmmo(EntityPlayer player)
{
  if (this.isArrow(player.getHeldItem(EnumHand.OFF_HAND)))
  {
      return player.getHeldItem(EnumHand.OFF_HAND);
  }
  else if (this.isArrow(player.getHeldItem(EnumHand.MAIN_HAND)))
  {
      return player.getHeldItem(EnumHand.MAIN_HAND);
  }
  else
  {
      for (int i = 0; i < player.inventory.getSizeInventory(); ++i)
      {
          ItemStack itemstack = player.inventory.getStackInSlot(i);

          if (this.isArrow(itemstack))
          {
              return itemstack;
          }
      }

      return ItemStack.EMPTY;
  }
}


    @net.minecraftforge.fml.common.eventhandler.SubscribeEvent
  public void joins(LivingUpdateEvent e) {
	Entity entity = e.getEntity();
//	if (e.getEntity() instanceof EntityPlayer){
//		for (int i = 0; i < ((EntityPlayer)entity).inventory.mainInventory.size(); i++ ){
//			ItemStack stack = ((EntityPlayer)entity).inventory.mainInventory.get(i);
//	boolean x = stack.hasTagCompound() && stack.getTagCompound().hasKey("Name");
//	if (x){
//		stack.setTranslatableName(stack.getTagCompound().getString("Name"));
//	}
//	boolean y = stack.hasDisplayName();
//	if (y){
//		stack.getTagCompound().setString("Name", stack.getDisplayName());
//		stack.clearCustomName();
//	}}
//		for (int i = 0; i < ((EntityPlayer)entity).inventory.offHandInventory.size(); i++ ){
//			ItemStack stack = ((EntityPlayer)entity).inventory.offHandInventory.get(i);
//	boolean x = stack.hasTagCompound() && stack.getTagCompound().hasKey("Name");
//	if (x){
//		stack.setTranslatableName(stack.getTagCompound().getString("Name"));
//	}
//	boolean y = stack.hasDisplayName();
//	if (y){
//		stack.getTagCompound().setString("Name", stack.getDisplayName());
//		stack.clearCustomName();
//	}}
//		for (int i = 0; i < ((EntityPlayer)entity).inventory.armorInventory.size(); i++ ){
//			ItemStack stack = ((EntityPlayer)entity).inventory.armorInventory.get(i);
//	boolean x = stack.hasTagCompound() && stack.getTagCompound().hasKey("Name");
//	if (x){
//		stack.setTranslatableName(stack.getTagCompound().getString("Name"));
//	}
//	boolean y = stack.hasDisplayName();
//	if (y){
//		stack.getTagCompound().setString("Name", stack.getDisplayName());
//		stack.clearCustomName();
//	}}
//	}
	World worldIn = entity.getEntityWorld();
	BlockPos entitypos = entity.getPosition();
	BlockPos pos = entitypos.down();
	IBlockState state = worldIn.getBlockState(pos);
	Block block = state.getBlock();
	
//			 if (worldIn.getBiome(pos) == TutorialMod.Meadow){
//					
//					
//				 if (entity instanceof EntityLivingBase){
//				EntityLivingBase entitylivingbase = ((EntityLivingBase)e.getEntity());
//				Random t = new Random();
//				if (worldIn.getBlockState(pos.down()).isTopSolid() && worldIn.getBlockState(pos).getBlock().isReplaceable(worldIn, pos) && t.nextInt(100) <= 25){
//					worldIn.setBlockState(pos, Blocks.FIRE.getDefaultState());
//				}
//				
//				
//				 }
//		}
			 if (worldIn.getBlockState(pos).getBlock() instanceof CustomBlockLeaves){
					
					
				 if (entity instanceof EntityLivingBase){
				EntityLivingBase entitylivingbase = ((EntityLivingBase)e.getEntity());
				int t = ((Planks.EnumType)state.getValue(CustomBlockLeaves.VARIANT)).getMeta();
				if (t == 1){
				        if (!entitylivingbase.isImmuneToFire() && entitylivingbase instanceof EntityLivingBase && !EnchantmentHelper.hasFrostWalkerEnchantment((EntityLivingBase)entitylivingbase))
				        {
				            entitylivingbase.attackEntityFrom(DamageSource.HOT_FLOOR, 1.0F);
				        }
				}
				
			
				 }
			 }
			 if (worldIn.getBlockState(pos).getBlock() instanceof CustomBlockLog){
					
					
				 if (entity instanceof EntityLivingBase){
				EntityLivingBase entitylivingbase = ((EntityLivingBase)e.getEntity());
				int t = ((Planks.EnumType)state.getValue(Planks.VARIANT)).getMeta();
				if (t == 1){
				        if (!entitylivingbase.isImmuneToFire() && entitylivingbase instanceof EntityLivingBase && !EnchantmentHelper.hasFrostWalkerEnchantment((EntityLivingBase)entitylivingbase))
				        {
				            entitylivingbase.attackEntityFrom(DamageSource.HOT_FLOOR, 1.0F);
				        }
				}
				 }
			 }
			 if (worldIn.getBlockState(pos).getBlock() instanceof Planks){
				if (entity instanceof EntityLivingBase){
					EntityLivingBase entitylivingbase = ((EntityLivingBase)e.getEntity());
					int t = ((Planks.EnumType)state.getValue(Planks.VARIANT)).getMeta();
					if (t == 1){
					        if (!entitylivingbase.isImmuneToFire() && entitylivingbase instanceof EntityLivingBase && !EnchantmentHelper.hasFrostWalkerEnchantment((EntityLivingBase)entitylivingbase))
					        {
					            entitylivingbase.attackEntityFrom(DamageSource.HOT_FLOOR, 1.0F);
					        }
					}
					
				 }
			 }
				 

	if (e.getEntity() instanceof EntityPlayer){
		EntityPlayer playerIn = ((EntityPlayer)e.getEntity());
		ItemStack x = findAmmo(playerIn);
		if (x.isEmpty() && (!playerIn.capabilities.isCreativeMode && !playerIn.isSpectator())){
			playerIn.capabilities.isFlying = false;
			playerIn.capabilities.allowFlying = false;
		}
	}
    }
 @SubscribeEvent

public void onDrops(BlockEvent.HarvestDropsEvent e)

{
	 if (e.getHarvester() != null) {
	 int level = EnchantmentHelper.getMaxEnchantmentLevel(EnchantmentInit.AUTOSMELT, e.getHarvester());
	 if (level>0) {
	 if (!e.getDrops().isEmpty()) {
		 for(int i = 0; i<e.getDrops().size(); i++)
		 if (!e.getWorld().isRemote&&!e.getDrops().get(i).isEmpty()) {
			 ItemStack drop = e.getDrops().get(i);
			 if (canSmelt(drop.copy())) {
				Random random=new Random();
				int levelFortune = EnchantmentHelper.getMaxEnchantmentLevel(Enchantments.FORTUNE, e.getHarvester());
				 ItemStack smeltedItem = FurnaceRecipes.instance().getSmeltingResult(drop);
				 if (levelFortune>0&&drop.getItem() != Item.getItemFromBlock(Blocks.COBBLESTONE)&&drop.getItem() != Item.getItemFromBlock(BlockInit.rainbow_block)){
				 smeltedItem.setCount(drop.getCount()+random.nextInt(levelFortune+2)-1);
				 } else{
				 smeltedItem.setCount(drop.getCount());
				 }
				 e.getDrops().set(i,smeltedItem.copy());
			 }
		 }}
	 }
	 }
}
private boolean canSmelt(ItemStack drop) {
	// TODO Auto-generated method stub
	ItemStack smelt=FurnaceRecipes.instance().getSmeltingResult(drop);
	if (smelt.isEmpty()) {
		return false;
	} else {
	return true;
	}
}
}

	

	 

   


    	
     
    
  
