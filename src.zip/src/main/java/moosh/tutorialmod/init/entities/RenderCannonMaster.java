
    package moosh.tutorialmod.init.entities;
     
    import moosh.tutorialmod.TutorialMod;
import net.minecraft.client.Minecraft;
import net.minecraft.client.model.ModelPlayer;
import net.minecraft.client.renderer.entity.RenderBiped;
import net.minecraft.entity.Entity;
import net.minecraft.util.ResourceLocation;
     
    public class RenderCannonMaster extends RenderBiped {
     
        public RenderCannonMaster(ModelPlayer model,
                float scale) {
            super(Minecraft.getMinecraft().getRenderManager(), model, scale);
            // TODO Auto-generated constructor stub
        }
     
        protected ResourceLocation getEntityTexture(Entity entity) {
            // TODO Auto-generated method stub
            return new ResourceLocation(TutorialMod.MODID, "textures/entity/cannonmaster.png");
        }
        
     
    }