
package moosh.tutorialmod.init.entities;
 
import moosh.tutorialmod.TutorialMod;
import moosh.tutorialmod.init.ItemInit;
import net.minecraft.util.ResourceLocation;
import net.minecraftforge.fml.common.registry.EntityRegistry;
 
 
public class EntityInit {
     ResourceLocation resource = new ResourceLocation(null);
    public static int currentEntityId = 0;
     
    public static void preInit(){
    	createEntity(new ResourceLocation("sorcery", "cannon_ball"), EntityCannonball.class, "cannon_ball");
    	
    	//createEntityWithEgg(new ResourceLocation("sorcery", "clone"), EntityClone.class, "clone", 10, 10);
    	createEntity(new ResourceLocation("sorcery", "cannonmaster"), EntityCannonMaster.class, "cannonmaster");
    
        

        
        

 
    }
 
    public static void init(){
        TutorialMod.proxy.registerEntityRenderers();
         

        
        
         
    }
     
    public static void createEntityWithEgg(ResourceLocation resource, Class entityClass, String entityName, int solidColor, int spotColor){
        int entityId = currentEntityId++;
        EntityRegistry.registerModEntity(resource, entityClass, entityName, entityId, TutorialMod.instance, 250, 1, true, solidColor, spotColor);
    }
    public static void createEntity(ResourceLocation resource, Class entityClass, String entityName){
        int entityId = currentEntityId++;
        EntityRegistry.registerModEntity(resource,entityClass, entityName, entityId, TutorialMod.instance, 250, 1, true);
    }
     

 
}
