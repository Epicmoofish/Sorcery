package moosh.tutorialmod.init.entities;

import moosh.tutorialmod.init.ItemInit;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.projectile.EntityThrowable;
import net.minecraft.util.DamageSource;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.RayTraceResult;
import net.minecraft.util.math.RayTraceResult.Type;
import net.minecraft.world.World;
import net.minecraft.world.storage.WorldInfo;

// Extends EntityThrowable which handles a projectile with gravity.
public class EntityCannonball extends EntityThrowable{

	
	private EntityLivingBase thrower;





	// Constructors for the entity taking a few different parameters
	public EntityCannonball(World worldIn)
    {
        super(worldIn);
    }
	
	public EntityCannonball(World worldIn, double x, double y, double z)
    {
        super(worldIn, x, y, z);
    }
	
	public EntityCannonball(World worldIn, EntityLivingBase throwerIn) {
		super(worldIn, throwerIn);
		this.thrower=throwerIn;
	}
	

	// This code runs when the throwable entity hits something.


	@Override
	protected void onImpact(RayTraceResult result) {
		Type x2 = Type.ENTITY;
						
						// TODO Auto-generated method stub
		// TODO Auto-generated method stub
				// Check if the water blast actually hit anything, and make sure it's a block
						if(result != null && result.typeOfHit == x2 ){
							BlockPos block = result.entityHit.getPosition();
							int x = block.getX();
							int y = block.getY();
							int z = block.getZ();
							BlockPos block2 = new BlockPos(x, y+1, z);

							World worldObj = result.entityHit.world;
							
			                
							
DamageSource source = ItemInit.causeCannonDamage(this, thrower);
result.entityHit.attackEntityFrom(source, 5);
			                
							worldObj.createExplosion(this.thrower, block.getX(),block.getY(),block.getZ(), 2, true);
						
							
							
							
							this.setDead();
							
							
							
							
							
						}
				
				
				// Check if the water blast actually hit anything, and make sure it's a block
				if(result != null && result.typeOfHit == Type.BLOCK){
					BlockPos blockToChange = result.getBlockPos().offset(result.sideHit);
					World worldObj = this.world;
			// We're only changing Air blocks to water with this item
						
						// Set the block at that location to water with the same flag the buckets use.
						
					worldObj.createExplosion(this.thrower, blockToChange.getX(),blockToChange.getY(),blockToChange.getZ(), 2, true);
						this.setDead();
					
						
					
					
				}
	}

	@Override
	protected float getGravityVelocity() {
		// TODO Auto-generated method stub
		return 0.001F;
	}


	


}
