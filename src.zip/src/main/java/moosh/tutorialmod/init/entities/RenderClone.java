
    package moosh.tutorialmod.init.entities;
     
    import moosh.tutorialmod.init.ThrowEvent;
import net.minecraft.client.Minecraft;
import net.minecraft.client.model.ModelPlayer;
import net.minecraft.client.renderer.entity.RenderBiped;
import net.minecraft.entity.Entity;
import net.minecraft.util.ResourceLocation;
import net.minecraftforge.fml.relauncher.Side;
import net.minecraftforge.fml.relauncher.SideOnly;
     
    public class RenderClone extends RenderBiped {
     public static boolean smallArms;
//     = Minecraft.getMinecraft().player.getSkinType().equals("slim");

     protected ResourceLocation getEntityTexture(Entity entity) {
			// TODO Auto-generated method stub
			
			ResourceLocation test = Minecraft.getMinecraft().player.getLocationSkin();
smallArms = Minecraft.getMinecraft().player.getSkinType().equals("slim");

			return test;
		}
        public RenderClone() {

            super(Minecraft.getMinecraft().getRenderManager(), new ModelPlayer(0.0F, false), 0.5F);
        	
          
           
            // TODO Auto-generated constructor stub
        }


		
        
     
    }