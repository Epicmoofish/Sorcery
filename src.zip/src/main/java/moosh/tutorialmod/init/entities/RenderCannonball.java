package moosh.tutorialmod.init.entities;

import moosh.tutorialmod.init.ItemInit;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.entity.RenderSnowball;

public class RenderCannonball extends RenderSnowball {
	
	public RenderCannonball() {
		super(Minecraft.getMinecraft().getRenderManager(), ItemInit.cannonball, Minecraft.getMinecraft().getRenderItem());
		// Try changing Items.snowball to make the water blast show like different items!
	}

}
