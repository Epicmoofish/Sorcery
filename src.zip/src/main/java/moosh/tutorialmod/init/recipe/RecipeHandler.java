package moosh.tutorialmod.init.recipe;

import moosh.tutorialmod.init.BlockInit;
import moosh.tutorialmod.init.ItemInit;
import net.minecraft.init.Blocks;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.crafting.Ingredient;
import net.minecraft.util.ResourceLocation;
import net.minecraftforge.fml.common.registry.GameRegistry;

public class RecipeHandler {
 public static void registerSmelting()
 {
	 GameRegistry.addSmelting(BlockInit.tutorial_ore, new ItemStack(ItemInit.smallElec), 10);
	 GameRegistry.addSmelting(BlockInit.ender_ore, new ItemStack(ItemInit.enderIngot), 10);
	 GameRegistry.addSmelting(BlockInit.dark_ore, new ItemStack(ItemInit.darkQuartz), 10);
	 GameRegistry.addSmelting(BlockInit.dark_quartz_block, new ItemStack(ItemInit.darkIngot), 10);
	 GameRegistry.addSmelting(BlockInit.rainbow_ore, new ItemStack(ItemInit.rainbowIngot), 10);
	 GameRegistry.addSmelting(BlockInit.rainbow_block, new ItemStack(ItemInit.rainbowSuperIngot), 10);
	 GameRegistry.addSmelting(Blocks.PLANKS, new ItemStack(BlockInit.planks,1,1), 10);



 }
 

}
