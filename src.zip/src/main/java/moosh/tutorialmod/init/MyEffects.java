package moosh.tutorialmod.init;

import javax.annotation.Nullable;

import net.minecraft.init.Bootstrap;
import net.minecraft.init.MobEffects;
import net.minecraft.potion.Potion;
import net.minecraft.util.ResourceLocation;

public class MyEffects extends MobEffects
{
    public static final Potion EXPLODE;


    @Nullable
    private static Potion getRegisteredMobEffect(String id)
    {
        Potion potion = Potion.REGISTRY.getObject(new ResourceLocation(id));

        if (potion == null)
        {
            throw new IllegalStateException("Invalid MobEffect requested: " + id);
        }
        else
        {
            return potion;
        }
    }

    static
    {
        if (!Bootstrap.isRegistered())
        {
            throw new RuntimeException("Accessed MobEffects before Bootstrap!");
        }
        else
        {
            EXPLODE = getRegisteredMobEffect("explode");
            
        }
    }
}