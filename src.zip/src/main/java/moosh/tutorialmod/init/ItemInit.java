
package moosh.tutorialmod.init;
 
import moosh.tutorialmod.TutorialMod;
import moosh.tutorialmod.init.entities.EntityCannonball;
import moosh.tutorialmod.init.items.BigElec;
import moosh.tutorialmod.init.items.BlankGlove;
import moosh.tutorialmod.init.items.BlazeGlove;
import moosh.tutorialmod.init.items.Cannon;
import moosh.tutorialmod.init.items.CustomFood;
import moosh.tutorialmod.init.items.DarkAxe;
import moosh.tutorialmod.init.items.DarkHoe;
import moosh.tutorialmod.init.items.DarkPick;
import moosh.tutorialmod.init.items.DarkQuartz;
import moosh.tutorialmod.init.items.DarkShovel;
import moosh.tutorialmod.init.items.DarkSword;
import moosh.tutorialmod.init.items.DeathIngot;
import moosh.tutorialmod.init.items.EndCharge;
import moosh.tutorialmod.init.items.EnderAxe;
import moosh.tutorialmod.init.items.EnderHoe;
import moosh.tutorialmod.init.items.EnderIngot;
import moosh.tutorialmod.init.items.EnderPickaxe;
import moosh.tutorialmod.init.items.EnderShovel;
import moosh.tutorialmod.init.items.EnderSword;
import moosh.tutorialmod.init.items.FlameFist;
import moosh.tutorialmod.init.items.InfusedDarkSword;
import moosh.tutorialmod.init.items.ItemBasic;
import moosh.tutorialmod.init.items.ItemCannonball;
import moosh.tutorialmod.init.items.ItemChickenGlove;
import moosh.tutorialmod.init.items.ItemCowGlove;
import moosh.tutorialmod.init.items.ItemDarkBoots;
import moosh.tutorialmod.init.items.ItemDarkChestplate;
import moosh.tutorialmod.init.items.ItemDarkHammer;
import moosh.tutorialmod.init.items.ItemDarkHelmet;
import moosh.tutorialmod.init.items.ItemDarkLeggings;
import moosh.tutorialmod.init.items.ItemDarkRod;
import moosh.tutorialmod.init.items.ItemElectro;
import moosh.tutorialmod.init.items.ItemEndermanGlove;
import moosh.tutorialmod.init.items.ItemEndermiteGlove;
import moosh.tutorialmod.init.items.ItemFireOrb;
import moosh.tutorialmod.init.items.ItemGhastGlove;
import moosh.tutorialmod.init.items.ItemGolemGlove;
import moosh.tutorialmod.init.items.ItemGuardianGlove;
import moosh.tutorialmod.init.items.ItemHorseGlove;
import moosh.tutorialmod.init.items.ItemMagmaCubeGlove;
import moosh.tutorialmod.init.items.ItemMysticOrb;
import moosh.tutorialmod.init.items.ItemOcelotGlove;
import moosh.tutorialmod.init.items.ItemOrbGemstone;
import moosh.tutorialmod.init.items.ItemPeaceOrb;
import moosh.tutorialmod.init.items.ItemRabbitGlove;
import moosh.tutorialmod.init.items.ItemRainbowHammer;
import moosh.tutorialmod.init.items.ItemRainbowIngot;
import moosh.tutorialmod.init.items.ItemSheepGlove;
import moosh.tutorialmod.init.items.ItemSkeletonGlove;
import moosh.tutorialmod.init.items.ItemSpiderGlove;
import moosh.tutorialmod.init.items.ItemSquidGlove;
import moosh.tutorialmod.init.items.ItemStaff;
import moosh.tutorialmod.init.items.ItemSuperRainbowIngot;
import moosh.tutorialmod.init.items.ItemWarOrb;
import moosh.tutorialmod.init.items.ItemWitherSkeletonGlove;
import moosh.tutorialmod.init.items.ItemZombieGlove;
import moosh.tutorialmod.init.items.MedElec;
import moosh.tutorialmod.init.items.ParrotGlove;
import moosh.tutorialmod.init.items.RainbowBow;
import moosh.tutorialmod.init.items.SmallElec;
import net.minecraft.block.state.IBlockState;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.RenderItem;
import net.minecraft.client.renderer.block.model.ModelResourceLocation;
import net.minecraft.creativetab.CreativeTabs;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.init.Blocks;
import net.minecraft.init.SoundEvents;
import net.minecraft.item.Item;
import net.minecraft.item.Item.ToolMaterial;
import net.minecraft.item.ItemArmor.ArmorMaterial;
import net.minecraft.item.ItemStack;
import net.minecraft.util.DamageSource;
import net.minecraft.util.EntityDamageSourceIndirect;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;
import net.minecraftforge.client.model.ModelLoader;
import net.minecraftforge.common.util.EnumHelper;
import net.minecraftforge.fml.common.FMLCommonHandler;
import net.minecraftforge.fml.common.registry.ForgeRegistries;
import net.minecraftforge.fml.relauncher.Side;
 
public class ItemInit {
	  public static CustomFood customFood;
	  public static ItemElectro customElectro;
	  public static FlameFist customFlame;
	  public static BigElec bigElec;
	  public static MedElec medElec;
	  public static SmallElec smallElec;
	  public static EndCharge endCharge;
	  public static EnderIngot enderIngot;
	  public static EnderSword enderSword;
	  public static EnderPickaxe enderPickaxe;
	  public static DarkQuartz darkQuartz;
	
	
	  
	  public static EnderAxe enderAxe;
	  public static EnderShovel enderShovel;
	  public static EnderHoe enderHoe;
	  public static DeathIngot darkIngot;
	  public static BlankGlove blankGlove;
	  public static BlazeGlove blazeGlove;
	  public static ItemEndermanGlove endermanGlove;
	  public static ItemEndermiteGlove endermiteGlove;
	  public static ItemSheepGlove sheepGlove;
	  public static ItemMagmaCubeGlove magmaGlove;
	  public static ItemWitherSkeletonGlove witherskeleGlove;
	  public static ParrotGlove batGlove;
	  public static ItemGhastGlove ghastGlove;
	  public static ItemGolemGlove golemGlove;
	  public static ItemCowGlove cowGlove;
	  public static ItemHorseGlove horseGlove;
	  public static ItemOcelotGlove ocelotGlove;
	  public static ItemRabbitGlove rabbitGlove;
	  public static ItemChickenGlove ChickenGlove;
	  public static ItemZombieGlove zombieGlove;
	  public static ItemSkeletonGlove skeletonGlove;
	  public static ItemSpiderGlove spiderGlove;
	  public static ItemGuardianGlove guardianGlove;
	  public static ItemSquidGlove squidGlove;
	  public static ItemDarkRod itemDarkRod;
	  public static DarkPick darkPick;
	  public static DarkSword darkSword;
	  public static InfusedDarkSword infdarkSword;
	  public static ItemDarkHammer infHammer;
	  public static DarkAxe darkAxe;
	  public static DarkShovel darkShovel;
	  public static DarkHoe darkHoe;
	  public static ItemDarkHelmet darkHelmet;
	  public static ItemDarkChestplate darkChestplate;
	  public static ItemDarkLeggings darkLeggings;
	  public static ItemDarkBoots darkBoots;
	  public static ItemRainbowHammer rainbowHammer;
	  public static ItemRainbowIngot rainbowIngot;
	  public static Cannon cannon;
	  public static ItemStaff staff;
	  public static ItemMysticOrb mysticOrb;
	  public static ItemFireOrb fireOrb;
	  public static ItemWarOrb warOrb;
	  public static ItemPeaceOrb peaceOrb;
	  public static ItemOrbGemstone allOrb;

	  public static ItemSuperRainbowIngot rainbowSuperIngot;
	  public static RainbowBow rainbowBow;
	  public static ItemCannonball cannonball;
	  

	  public static DamageSource cannonballDmg = new DamageSource("Cannon");
	  

	    public static ArmorMaterial dark;
	  
	 public static ToolMaterial toolMaterialEnder;
	 public static ToolMaterial toolMaterialDark;
	 public static ToolMaterial toolMaterialRainbow;
	
    
    public static void preInit(){
 
    	
    	toolMaterialEnder = EnumHelper.addToolMaterial("Ender", 4, 3500, 14f, 6f, 30);
    	toolMaterialDark = EnumHelper.addToolMaterial("Dark", 5, 5000, 24f, 9f, 40);
    	toolMaterialRainbow = EnumHelper.addToolMaterial("Rainbow", 6, 10000, 30f, 9f, 40);
        // Initialize items

    	dark = EnumHelper.addArmorMaterial("dark", "sorcery:dark", 45, new int[]{3, 6, 8, 3}, 9, SoundEvents.ITEM_ARMOR_EQUIP_IRON, 6);
    	 customFood = new CustomFood();
    
    	 customElectro = new ItemElectro();
    	 
    	 rainbowHammer = new ItemRainbowHammer();
    	 rainbowIngot = new ItemRainbowIngot();
    	 rainbowSuperIngot = new ItemSuperRainbowIngot();
    	 customFlame = new FlameFist();
         bigElec = new BigElec();
         medElec = new MedElec();
         smallElec = new SmallElec();
         endCharge = new EndCharge();
         enderIngot = new EnderIngot();
         enderSword = new EnderSword();
         enderPickaxe = new EnderPickaxe();
         darkQuartz = new DarkQuartz();
         enderAxe = new EnderAxe();
         enderShovel = new EnderShovel();
         enderHoe = new EnderHoe();
         darkIngot = new DeathIngot();
         blankGlove = new BlankGlove();
         endermanGlove = new ItemEndermanGlove();
         sheepGlove = new ItemSheepGlove();
         endermiteGlove = new ItemEndermiteGlove();
         skeletonGlove = new ItemSkeletonGlove();
         zombieGlove = new ItemZombieGlove();
         spiderGlove = new ItemSpiderGlove();
         guardianGlove = new ItemGuardianGlove();
         squidGlove = new ItemSquidGlove();
         
         magmaGlove = new ItemMagmaCubeGlove();
         witherskeleGlove = new ItemWitherSkeletonGlove();
         blazeGlove = new BlazeGlove();
         batGlove = new ParrotGlove();
         ghastGlove = new ItemGhastGlove();
         golemGlove = new ItemGolemGlove();
         cowGlove = new ItemCowGlove();
         horseGlove = new ItemHorseGlove();
         ocelotGlove = new ItemOcelotGlove();
         rabbitGlove = new ItemRabbitGlove();
         ChickenGlove = new ItemChickenGlove();
         itemDarkRod = new ItemDarkRod();
         darkPick = new DarkPick();
         darkSword = new DarkSword();
         infdarkSword = new InfusedDarkSword();
         infHammer = new ItemDarkHammer();
         darkAxe = new DarkAxe();
         darkShovel = new DarkShovel();
         darkHoe = new DarkHoe();
         cannon = new Cannon();
         mysticOrb = new ItemMysticOrb();
         fireOrb = new ItemFireOrb();
         warOrb = new ItemWarOrb();
         peaceOrb = new ItemPeaceOrb();
         allOrb = new ItemOrbGemstone();
         staff = new ItemStaff();
     cannonball = new ItemCannonball();
         darkHelmet = new ItemDarkHelmet();
         darkChestplate = new ItemDarkChestplate();
         darkLeggings = new ItemDarkLeggings();
         darkBoots = new ItemDarkBoots();
         rainbowBow = new RainbowBow();

    }
    public static void registerItemz(Item item)
    {
       item.setCreativeTab(CreativeTabs.MISC);
       
     
        ForgeRegistries.ITEMS.register(item);
        ModelLoader.setCustomModelResourceLocation(item, 0, new ModelResourceLocation(item.getRegistryName(), "inventory"));
        
    }
    public static void registerstuff(){
    	
         ForgeRegistries.ITEMS.register(customFood);
    	 ForgeRegistries.ITEMS.register(customElectro);
    	 ForgeRegistries.ITEMS.register(customFlame);
    	 
    	 ForgeRegistries.ITEMS.register(bigElec);
    	 ForgeRegistries.ITEMS.register(medElec);
    	 ForgeRegistries.ITEMS.register(smallElec);
    	 
    	 ForgeRegistries.ITEMS.register(endCharge);
    	 ForgeRegistries.ITEMS.register(enderIngot);
    	 ForgeRegistries.ITEMS.register(enderSword);
    	 ForgeRegistries.ITEMS.register(enderPickaxe);
    	 ForgeRegistries.ITEMS.register(darkQuartz);
    	 ForgeRegistries.ITEMS.register(enderAxe);
    	 ForgeRegistries.ITEMS.register(enderShovel);
    	 ForgeRegistries.ITEMS.register(enderHoe);
    	 ForgeRegistries.ITEMS.register(darkIngot);
    	 ForgeRegistries.ITEMS.register(blankGlove);
    	 ForgeRegistries.ITEMS.register(blazeGlove);
    	 ForgeRegistries.ITEMS.register(endermanGlove);
    	 ForgeRegistries.ITEMS.register(endermiteGlove);
    	 ForgeRegistries.ITEMS.register(magmaGlove);
    	 ForgeRegistries.ITEMS.register(spiderGlove);
    	 ForgeRegistries.ITEMS.register(skeletonGlove);
    	 ForgeRegistries.ITEMS.register(zombieGlove);
    	 ForgeRegistries.ITEMS.register(guardianGlove);
    	 ForgeRegistries.ITEMS.register(squidGlove);
    	 ForgeRegistries.ITEMS.register(sheepGlove);
    	 ForgeRegistries.ITEMS.register(witherskeleGlove);
    	 ForgeRegistries.ITEMS.register(batGlove);
    	 ForgeRegistries.ITEMS.register(ghastGlove);
    	 ForgeRegistries.ITEMS.register(golemGlove);
//    	 ForgeRegistries.SOUND_EVENTS.register(value);
//    	 ForgeRegistries.BIOMES.register(new BiomeBoil(new BiomeProperties("FakeHell").setBaseHeight(0.25F).setRainDisabled().setRainfall(0.0F)));
    	 ForgeRegistries.ITEMS.register(cowGlove);
    	 ForgeRegistries.ITEMS.register(horseGlove);
    	 ForgeRegistries.ITEMS.register(ocelotGlove);
    	 ForgeRegistries.ITEMS.register(rabbitGlove);
    	 ForgeRegistries.ITEMS.register(ChickenGlove);
    	 ForgeRegistries.ITEMS.register(itemDarkRod);
    	 ForgeRegistries.ITEMS.register(darkPick);
    	 ForgeRegistries.ITEMS.register(darkSword);
    	 ForgeRegistries.ITEMS.register(infdarkSword);
    	 ForgeRegistries.ITEMS.register(infHammer);
    	 ForgeRegistries.ITEMS.register(darkAxe);
    	 ForgeRegistries.ITEMS.register(darkShovel);
    	 ForgeRegistries.ITEMS.register(darkHoe);
    	 ForgeRegistries.ITEMS.register(darkHelmet);
    	 ForgeRegistries.ITEMS.register(darkChestplate);
    	 ForgeRegistries.ITEMS.register(darkLeggings);
    	 ForgeRegistries.ITEMS.register(darkBoots);
    	 ForgeRegistries.ITEMS.register(rainbowHammer);
    	 ForgeRegistries.ITEMS.register(rainbowIngot);
    	 ForgeRegistries.ITEMS.register(rainbowSuperIngot);
    	 ForgeRegistries.ITEMS.register(cannon);
    	 ForgeRegistries.ITEMS.register(mysticOrb);
    	 ForgeRegistries.ITEMS.register(fireOrb);
    	 
    	 ForgeRegistries.ITEMS.register(warOrb);
    	 ForgeRegistries.ITEMS.register(peaceOrb);
    	 ForgeRegistries.ITEMS.register(allOrb);
    	 ForgeRegistries.ITEMS.register(staff);
    	 ForgeRegistries.ITEMS.register(cannonball);
    	 ForgeRegistries.ITEMS.register(rainbowBow);

    	



    	 
    	 
    	 

       
        
    }
    public static void registerItem(String name, CreativeTabs tab, int size)
    {
    	
    	Item item = new ItemBasic(name, tab, size);
      
       
     
        ForgeRegistries.ITEMS.register(item);
        
        ModelLoader.setCustomModelResourceLocation(item, 0, new ModelResourceLocation(item.getRegistryName(), "inventory"));
        
    }
    public static void init(){
        // Item inventory Rendering
       
    	   if(FMLCommonHandler.instance().getSide() == Side.CLIENT)
           {
               RenderItem renderItem = Minecraft.getMinecraft().getRenderItem();
               renderItem.getItemModelMesher().register(customFood,0, new ModelResourceLocation(TutorialMod.instance.MODID +":" + customFood.name, "inventory"));
               renderItem.getItemModelMesher().register(customElectro,0, new ModelResourceLocation(TutorialMod.instance.MODID +":" + customElectro.name, "inventory"));
               renderItem.getItemModelMesher().register(customFlame,0, new ModelResourceLocation(TutorialMod.instance.MODID +":" + customFlame.name, "inventory"));
               renderItem.getItemModelMesher().register(bigElec,0, new ModelResourceLocation(TutorialMod.instance.MODID +":" + bigElec.name, "inventory"));
               renderItem.getItemModelMesher().register(medElec,0, new ModelResourceLocation(TutorialMod.instance.MODID +":" + medElec.name, "inventory"));
               renderItem.getItemModelMesher().register(smallElec,0, new ModelResourceLocation(TutorialMod.instance.MODID +":" + smallElec.name, "inventory"));
               renderItem.getItemModelMesher().register(endCharge,0, new ModelResourceLocation(TutorialMod.instance.MODID +":" + endCharge.name, "inventory"));
               renderItem.getItemModelMesher().register(enderIngot,0, new ModelResourceLocation(TutorialMod.instance.MODID +":" + enderIngot.name, "inventory"));
               renderItem.getItemModelMesher().register(enderSword,0, new ModelResourceLocation(TutorialMod.instance.MODID +":" + enderSword.name, "inventory"));
               renderItem.getItemModelMesher().register(enderPickaxe,0, new ModelResourceLocation(TutorialMod.instance.MODID +":" + enderPickaxe.name, "inventory"));
               renderItem.getItemModelMesher().register(darkQuartz,0, new ModelResourceLocation(TutorialMod.instance.MODID +":" + darkQuartz.name, "inventory"));
               renderItem.getItemModelMesher().register(enderAxe,0, new ModelResourceLocation(TutorialMod.instance.MODID +":" + enderAxe.name, "inventory"));
               renderItem.getItemModelMesher().register(enderShovel,0, new ModelResourceLocation(TutorialMod.instance.MODID +":" + enderShovel.name, "inventory"));
               renderItem.getItemModelMesher().register(enderHoe,0, new ModelResourceLocation(TutorialMod.instance.MODID +":" + enderHoe.name, "inventory"));
               renderItem.getItemModelMesher().register(darkIngot,0, new ModelResourceLocation(TutorialMod.instance.MODID +":" + darkIngot.name, "inventory"));
               renderItem.getItemModelMesher().register(blankGlove,0, new ModelResourceLocation(TutorialMod.instance.MODID +":" + blankGlove.name, "inventory"));
               renderItem.getItemModelMesher().register(blazeGlove,0, new ModelResourceLocation(TutorialMod.instance.MODID +":" + blazeGlove.name, "inventory"));
               renderItem.getItemModelMesher().register(skeletonGlove,0, new ModelResourceLocation(TutorialMod.instance.MODID +":" + skeletonGlove.name, "inventory"));
               renderItem.getItemModelMesher().register(spiderGlove,0, new ModelResourceLocation(TutorialMod.instance.MODID +":" + spiderGlove.name, "inventory"));
               renderItem.getItemModelMesher().register(zombieGlove,0, new ModelResourceLocation(TutorialMod.instance.MODID +":" + zombieGlove.name, "inventory"));
               renderItem.getItemModelMesher().register(guardianGlove,0, new ModelResourceLocation(TutorialMod.instance.MODID +":" + guardianGlove.name, "inventory"));
               renderItem.getItemModelMesher().register(squidGlove,0, new ModelResourceLocation(TutorialMod.instance.MODID +":" + squidGlove.name, "inventory"));
               renderItem.getItemModelMesher().register(batGlove,0, new ModelResourceLocation(TutorialMod.instance.MODID +":" + batGlove.name, "inventory"));
               renderItem.getItemModelMesher().register(ghastGlove,0, new ModelResourceLocation(TutorialMod.instance.MODID +":" + ghastGlove.name, "inventory"));
               renderItem.getItemModelMesher().register(golemGlove,0, new ModelResourceLocation(TutorialMod.instance.MODID +":" + golemGlove.name, "inventory"));
               renderItem.getItemModelMesher().register(cowGlove,0, new ModelResourceLocation(TutorialMod.instance.MODID +":" + cowGlove.name, "inventory"));
               renderItem.getItemModelMesher().register(horseGlove,0, new ModelResourceLocation(TutorialMod.instance.MODID +":" + horseGlove.name, "inventory"));
               renderItem.getItemModelMesher().register(ocelotGlove,0, new ModelResourceLocation(TutorialMod.instance.MODID +":" + ocelotGlove.name, "inventory"));
               renderItem.getItemModelMesher().register(rabbitGlove,0, new ModelResourceLocation(TutorialMod.instance.MODID +":" + rabbitGlove.name, "inventory"));
               renderItem.getItemModelMesher().register(ChickenGlove,0, new ModelResourceLocation(TutorialMod.instance.MODID +":" + ChickenGlove.name, "inventory"));
               renderItem.getItemModelMesher().register(endermanGlove,0, new ModelResourceLocation(TutorialMod.instance.MODID +":" + endermanGlove.name, "inventory"));
               renderItem.getItemModelMesher().register(endermiteGlove,0, new ModelResourceLocation(TutorialMod.instance.MODID +":" + endermiteGlove.name, "inventory"));
               renderItem.getItemModelMesher().register(magmaGlove,0, new ModelResourceLocation(TutorialMod.instance.MODID +":" + magmaGlove.name, "inventory"));
               renderItem.getItemModelMesher().register(sheepGlove,0, new ModelResourceLocation(TutorialMod.instance.MODID +":" + sheepGlove.name, "inventory"));
               renderItem.getItemModelMesher().register(witherskeleGlove,0, new ModelResourceLocation(TutorialMod.instance.MODID +":" + witherskeleGlove.name, "inventory"));
               renderItem.getItemModelMesher().register(itemDarkRod,0, new ModelResourceLocation(TutorialMod.instance.MODID +":" + itemDarkRod.name, "inventory"));
               renderItem.getItemModelMesher().register(darkPick,0, new ModelResourceLocation(TutorialMod.instance.MODID +":" + darkPick.name, "inventory"));
               renderItem.getItemModelMesher().register(darkSword,0, new ModelResourceLocation(TutorialMod.instance.MODID +":" + darkSword.name, "inventory"));
               renderItem.getItemModelMesher().register(infdarkSword,0, new ModelResourceLocation(TutorialMod.instance.MODID +":" + darkSword.name, "inventory"));
               renderItem.getItemModelMesher().register(darkAxe,0, new ModelResourceLocation(TutorialMod.instance.MODID +":" + darkAxe.name, "inventory"));
               renderItem.getItemModelMesher().register(darkShovel,0, new ModelResourceLocation(TutorialMod.instance.MODID +":" + darkShovel.name, "inventory"));
               renderItem.getItemModelMesher().register(darkHoe,0, new ModelResourceLocation(TutorialMod.instance.MODID +":" + darkHoe.name, "inventory"));
               renderItem.getItemModelMesher().register(darkHelmet,0, new ModelResourceLocation(TutorialMod.instance.MODID +":" + darkHelmet.name, "inventory"));
               renderItem.getItemModelMesher().register(darkChestplate,0, new ModelResourceLocation(TutorialMod.instance.MODID +":" + darkChestplate.name, "inventory"));
               renderItem.getItemModelMesher().register(darkLeggings,0, new ModelResourceLocation(TutorialMod.instance.MODID +":" + darkLeggings.name, "inventory"));
               renderItem.getItemModelMesher().register(darkBoots,0, new ModelResourceLocation(TutorialMod.instance.MODID +":" + darkBoots.name, "inventory"));
               renderItem.getItemModelMesher().register(rainbowHammer,0, new ModelResourceLocation(TutorialMod.instance.MODID +":" + rainbowHammer.name, "inventory"));
               renderItem.getItemModelMesher().register(rainbowSuperIngot,0, new ModelResourceLocation(TutorialMod.instance.MODID +":" + rainbowSuperIngot.name, "inventory"));
               renderItem.getItemModelMesher().register(infHammer,0, new ModelResourceLocation(TutorialMod.instance.MODID +":" + rainbowHammer.name, "inventory"));
               renderItem.getItemModelMesher().register(rainbowIngot,0, new ModelResourceLocation(TutorialMod.instance.MODID +":" + rainbowIngot.name, "inventory"));
               renderItem.getItemModelMesher().register(cannon,0, new ModelResourceLocation(TutorialMod.instance.MODID +":" + cannon.name, "inventory"));
               renderItem.getItemModelMesher().register(fireOrb,0, new ModelResourceLocation(TutorialMod.instance.MODID +":" + fireOrb.name, "inventory"));
               renderItem.getItemModelMesher().register(mysticOrb,0, new ModelResourceLocation(TutorialMod.instance.MODID +":" + mysticOrb.name, "inventory"));
               renderItem.getItemModelMesher().register(peaceOrb,0, new ModelResourceLocation(TutorialMod.instance.MODID +":" + peaceOrb.name, "inventory"));
               renderItem.getItemModelMesher().register(allOrb,0, new ModelResourceLocation(TutorialMod.instance.MODID +":" + allOrb.name, "inventory"));
               renderItem.getItemModelMesher().register(warOrb,0, new ModelResourceLocation(TutorialMod.instance.MODID +":" + warOrb.name, "inventory"));
               renderItem.getItemModelMesher().register(staff,0, new ModelResourceLocation(TutorialMod.instance.MODID +":" + staff.name, "inventory"));
               renderItem.getItemModelMesher().register(cannonball,0, new ModelResourceLocation(TutorialMod.instance.MODID +":" + cannonball.name, "inventory"));
               renderItem.getItemModelMesher().register(rainbowBow,0, new ModelResourceLocation(TutorialMod.instance.MODID +":" + rainbowBow.name, "inventory"));
               
               
              
            
            
            
           }
           

        }
    
    
    
    public static final CreativeTabs tabGlove = new CreativeTabs("glove") {
       @Override public ItemStack getTabIconItem() {
       	return new ItemStack(ItemInit.blankGlove);
    }
        
    };
    public static DamageSource causeCannonDamage(EntityCannonball entityCannonball, Entity thrower) {
		// TODO Auto-generated method stub
		return (new EntityDamageSourceIndirect("Cannon", entityCannonball, thrower));
	}
 public static void superBreak(int size, World worldIn, IBlockState state, BlockPos pos, EntityLivingBase entityLiving, ItemStack stack){
	 if (entityLiving instanceof EntityPlayer){
	 if (state.getBlock().canHarvestBlock(worldIn, pos, (EntityPlayer) entityLiving)&& state.getBlock() != BlockInit.rainbow_ore&& state.getBlock() != Blocks.REDSTONE_ORE&& state.getBlock() != Blocks.LIT_REDSTONE_ORE){
		 
			BlockPos pos2;


			IBlockState a;
			int x = pos.getX();
			int y = pos.getY();
			int z = pos.getZ();
			int x2 = x;
			int y2 = y;
			int z2 = z;
			for (int c=1; c<size+1; c++){
			y2=y+c-Math.round((size+1)/2);
				pos2 = new BlockPos(x2,y2,z2);
				a = worldIn.getBlockState(pos2);
			for (int b=1; b<size+1; b++){
				z2=z+b-Math.round((size+1)/2);
				pos2 = new BlockPos(x2,y2,z2);
				a = worldIn.getBlockState(pos2);
			for (int i=1; i<size+1; i++){
			x2=x+i-Math.round((size+1)/2);
				pos2 = new BlockPos(x2,y2,z2);
				a = worldIn.getBlockState(pos2);

				
				if (worldIn.getBlockState(pos2) == state){
					stack.damageItem(1, entityLiving);
					 
		worldIn.destroyBlock(pos2, true);
					
				}} x2=x;
			} z2=z;
			}
			y2=y;
				}
	 if (state.getBlock() != Blocks.REDSTONE_ORE || state.getBlock() != Blocks.LIT_REDSTONE_ORE){
		 BlockPos pos2;


			IBlockState a;
			int x = pos.getX();
			int y = pos.getY();
			int z = pos.getZ();
			int x2 = x;
			int y2 = y;
			int z2 = z;
			for (int c=1; c<size+1; c++){
			y2=y+c-2;
				pos2 = new BlockPos(x2,y2,z2);
				a = worldIn.getBlockState(pos2);
			for (int b=1; b<size+1; b++){
				z2=z+b-Math.round((size+1)/2);
				pos2 = new BlockPos(x2,y2,z2);
				a = worldIn.getBlockState(pos2);
			for (int i=1; i<size+1; i++){
			x2=x+i-Math.round((size+1)/2);
				pos2 = new BlockPos(x2,y2,z2);
				a = worldIn.getBlockState(pos2);

				
				if (worldIn.getBlockState(pos2).getBlock() == Blocks.REDSTONE_ORE || worldIn.getBlockState(pos2).getBlock() == Blocks.LIT_REDSTONE_ORE){
					stack.damageItem(1, entityLiving);
					 
		worldIn.destroyBlock(pos2, true);
					
				}} x2=x;
			} z2=z;
			}
			y2=y;
	 }
	 }
 }
    
 
}