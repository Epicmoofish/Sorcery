package moosh.tutorialmod;

import java.util.List;

import javax.annotation.Nullable;

import com.google.common.collect.Lists;

import moosh.tutorialmod.init.BlockInit;
import moosh.tutorialmod.init.ItemInit;
import moosh.tutorialmod.init.ThrowEvent;
import moosh.tutorialmod.init.entities.EntityInit;
import moosh.tutorialmod.init.gen.DarkOreGen;
import moosh.tutorialmod.init.gen.EndOreGen;
import moosh.tutorialmod.init.gen.OreGen;
import moosh.tutorialmod.init.gen.RainbowOreGen;
import moosh.tutorialmod.init.gen.TutorialTreeGen;
import moosh.tutorialmod.init.recipe.RecipeHandler;
import moosh.tutorialmod.proxy.CommonProxy;
import net.minecraft.block.Block;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.init.Blocks;
import net.minecraft.util.ResourceLocation;
import net.minecraft.util.registry.RegistryNamespaced;
import net.minecraft.world.World;
import net.minecraft.world.biome.Biome;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.common.SidedProxy;
import net.minecraftforge.fml.common.event.FMLInitializationEvent;
import net.minecraftforge.fml.common.event.FMLPostInitializationEvent;
import net.minecraftforge.fml.common.event.FMLPreInitializationEvent;
import net.minecraftforge.fml.common.registry.GameRegistry;






















@Mod(modid=TutorialMod.MODID, version=TutorialMod.VERSION, acceptedMinecraftVersions="[1.12]")
public class TutorialMod
{
	public static final RegistryNamespaced<ResourceLocation, Biome> REGISTRY = net.minecraftforge.registries.GameData.getWrapper(Biome.class);

    public static Biome FakeNether;
    public static Biome GreenLand;
  public static final String MODID = "sorcery";
  public static final String VERSION = "1.1";

  @Mod.Instance(MODID)
  public static TutorialMod instance;
  @SidedProxy(modId=MODID, clientSide="moosh.tutorialmod.proxy.ClientProxy", serverSide="moosh.tutorialmod.proxy.CommonProxy")
  public static CommonProxy proxy;
  
  public TutorialMod() {}
  
  @Mod.EventHandler
  public void preInit(FMLPreInitializationEvent event)
  {
    ItemInit.preInit();
    ItemInit.registerstuff();
    EntityInit.preInit();
    
    BlockInit.init();
    BlockInit.register();
    GameRegistry.registerWorldGenerator(new OreGen(), 0);
    GameRegistry.registerWorldGenerator(new EndOreGen(), 0);
    GameRegistry.registerWorldGenerator(new DarkOreGen(), 0);
    GameRegistry.registerWorldGenerator(new RainbowOreGen(), 0);
    
    
//    BiomeInit.registerBiomes();
//    FakeNether = new BiomeBoil(new BiomeProperties("FakeNether").setBaseHeight(0.0F).setHeightVariation(0.2F).setTemperature(0.5F).setWaterColor(14485255).setRainfall(0.0f).setRainDisabled(), 5439488, 5439488, 5439488);
////    GreenLand = new BiomeBase(new BiomeProperties("Greenland").setBaseHeight(0.0F).setHeightVariation(0.2F).setTemperature(0.5F).setWaterColor(48896).setRainfall(0.0f).setRainDisabled(),  48896, 48896, 48896, Blocks.GRASS.getDefaultState(), Blocks.DIRT.getDefaultState(), 35);
//    
//    BiomeType type = BiomeType.WARM;
//    Biome biome = FakeNether;
//    int weight = 6;
//    boolean isSpawnBiome = true;
//    
//    BiomeList.registerOverworldBiomes(FakeNether, BiomeType.WARM, true, 6);
//    
//    BiomeManager.addBiome(type, new BiomeEntry(biome, weight));
//    if(isSpawnBiome){
//        BiomeManager.addSpawnBiome(biome);
//    }
//    BiomeManager.addStrongholdBiome(biome);
////    Biome biome2 = GreenLand;
////    int weight2 = 6;
////    
////    
////    BiomeList.registerOverworldBiomes(GreenLand, BiomeType.WARM, true, 6);
////    
////    BiomeManager.addBiome(type, new BiomeEntry(biome2, weight2));
////    if(isSpawnBiome){
////        BiomeManager.addSpawnBiome(biome2);
////    }
////    BiomeManager.addStrongholdBiome(biome2);
////    ForgeRegistries.BIOMES.registerAll(Meadow);
////    MinecraftForge.EVENT_BUS.register(new BiomeList());
//    
// 
////TutorialTreeGen.register();
//
//
////RedhotTreeGen.register();
//    
  MinecraftForge.EVENT_BUS.register(new ThrowEvent());
//  }
//
//@Mod.EventHandler
//  public void registerBiome(RegistryEvent.Register<Biome> event) {
//      event.getRegistry().registerAll(
//      		
//          //================================
//      		
//          TutorialMod.FakeNether
////          TutorialMod.GreenLand
//          //================================
//      );
//}
  }
  @Mod.EventHandler
  public void init(FMLInitializationEvent event)
  {
    ItemInit.init();
    TutorialTreeGen.register();
//    ForgeRegistries.BIOMES.registerAll(FakeNether);
    
    BlockInit.registerRenders();
    RecipeHandler.registerSmelting();
    EntityInit.init();
  }
  @Mod.EventHandler
  public void postInit(FMLPostInitializationEvent event)
  {
	 
	  
  }
  
  @Nullable
  public static EntityLivingBase getClosestEntityLiving(double x, double y, double z, double p_190525_7_, World worldIn)
  {
      double d0 = -1.0D;
      EntityLivingBase entityplayer = null;

      for (int i = 0; i < worldIn.loadedEntityList.size(); ++i)
      {
          Entity entityplayer1 = worldIn.loadedEntityList.get(i);

         
              double d1 = entityplayer1.getDistanceSq(x, y, z);

              if ((p_190525_7_ < 0.0D || d1 < p_190525_7_ * p_190525_7_) && (d0 == -1.0D || d1 < d0))
              {
                  d0 = d1;
                  if (entityplayer1 instanceof EntityLivingBase){
                  entityplayer = (EntityLivingBase)entityplayer1;
                  }
              }
          
      }

      return entityplayer;
  }
  @Nullable
  public static List<EntityPlayer> getPlayersInRange(double x, double y, double z, double range, World worldIn)
  {
      double d0 = -1.0D;
      List<EntityPlayer> list = Lists.newArrayList();
      EntityPlayer entityplayer;

      for (int i = 0; i < worldIn.playerEntities.size(); ++i)
      {
          Entity entityplayer1 = worldIn.playerEntities.get(i);

         
              double d1 = entityplayer1.getDistanceSq(x, y, z);

              if ((range < 0.0D || d1 < range* range) && (d0 == -1.0D || d1 < d0))
              {
                  d0 = d1;
                  if (entityplayer1 instanceof EntityPlayer){
                  entityplayer = (EntityPlayer)entityplayer1;
                  list.add(entityplayer);
                  }
              }
          
      }

      return list;
  }
 public static Block blockToOre(Block block){
	 if (block == Blocks.COAL_BLOCK)
     {
         return Blocks.COAL_ORE;
     }
     else if (block == Blocks.DIAMOND_BLOCK)
     {
         return Blocks.DIAMOND_ORE;
     }
     else if (block == Blocks.LAPIS_BLOCK)
     {
         return Blocks.LAPIS_ORE;
     }
     else if (block == Blocks.EMERALD_BLOCK)
     {
         return Blocks.EMERALD_ORE;
     }
     else if (block == Blocks.IRON_BLOCK)
     {
         return Blocks.IRON_ORE;
     }
     else if (block == Blocks.GOLD_BLOCK)
     {
         return Blocks.GOLD_ORE;
     }
     else if (block == BlockInit.dark_quartz_block)
     {
         return BlockInit.dark_ore;
     }
     else if (block == BlockInit.ender_block)
     {
         return BlockInit.ender_ore;
     }
     else if (block == BlockInit.rainbow_block || block == BlockInit.super_rainbow_block)
     {
         return BlockInit.rainbow_ore;
     }
     else if (block == BlockInit.silver_block)
     {
         return BlockInit.silver_ore;
     }
  
     else
     {
         return block == Blocks.QUARTZ_BLOCK ? Blocks.QUARTZ_ORE : null;
     }
 }
 public static Block oreToBlock(Block block){
	 if (block == Blocks.COAL_ORE)
     {
         return Blocks.COAL_BLOCK;
     }
     else if (block == Blocks.DIAMOND_ORE)
     {
         return Blocks.DIAMOND_BLOCK;
     }
     else if (block == Blocks.LAPIS_ORE)
     {
         return Blocks.LAPIS_BLOCK;
     }
     else if (block == Blocks.EMERALD_ORE)
     {
         return Blocks.EMERALD_BLOCK;
     }
     else if (block == Blocks.IRON_ORE)
     {
         return Blocks.IRON_BLOCK;
     }
     else if (block == Blocks.GOLD_ORE)
     {
         return Blocks.GOLD_BLOCK;
     }
     else if (block == BlockInit.dark_ore)
     {
         return BlockInit.dark_quartz_block;
     }
     else if (block == BlockInit.ender_ore)
     {
         return BlockInit.ender_block;
     }
     else if (block == BlockInit.rainbow_ore)
     {
         return BlockInit.rainbow_block;
     }
     else if (block == BlockInit.silver_ore)
     {
         return BlockInit.silver_block;
     }
  
     else
     {
         return block == Blocks.QUARTZ_ORE ? Blocks.QUARTZ_BLOCK : block;
     }
 }
public static int round(double d){
	    double dAbs = Math.abs(d);
	  
	    int i = (int) dAbs;
	    double result = dAbs - (double) i;
	    if(result<0.5){
	        return d<0 ? -i : i;            
	    }else{
	        return d<0 ? -(i+1) : i+1;          
	    }
	}

 

}